package com.rst.sopm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SOPMApplicationTests {

	@Test
	void contextLoads() {
	}

}
