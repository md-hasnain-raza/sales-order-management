package com.rst.sopm.jwt;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.rst.sopm.dto.request.PermissionRequestDto;
import com.rst.sopm.dto.response.PermissionResponseDto;

@Component
public class EntitySetter {

	@Autowired
	private PasswordEncoder bcryptEncoder;

	public UserData userAddUpdateDtoUserDb(UserAddUpdateRequestDto obj) {
		if (obj == null)
			return null;
		return new UserData(obj.getId() != null ? obj.getId() : null, obj.getUserName(), obj.getEmail(),
				bcryptEncoder.encode(obj.getPassword()), obj.getUserType().getId().intValue(),
				new Company(obj.getCompanyId()), new Date(), 1, new Date(), 1, true);
	}

	public UserResponseDto userToUserResponseDto(UserData obj) {
		if (obj == null)
			return null;
		IdNameDto company = new IdNameDto(obj.getCompany().getId(), obj.getCompany().getName());
		return new UserResponseDto(obj.getId(), obj.getName(), new IdNameDto(obj.getUserType().longValue()),
				obj.getIsActive(), obj.getEmail(), company);

	}



}
