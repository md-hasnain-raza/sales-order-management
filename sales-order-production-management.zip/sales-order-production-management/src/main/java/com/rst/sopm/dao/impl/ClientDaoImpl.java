package com.rst.sopm.dao.impl;

import com.rst.sopm.dao.ClientDao;
import com.rst.sopm.dto.ClientDto;
import com.rst.sopm.entity.Client;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ClientDaoImpl implements ClientDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public Client save(Client client) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a Permission with the same name or apiEndpoint already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Client> cr = cb.createQuery(Client.class);
        Root<Client> root = cr.from(Client.class);
        List<Predicate> andPredicates = new ArrayList<>();
        String clientName = client.getName();
        if (clientName != null) {
            andPredicates.add(cb.equal(cb.lower(root.get("name")), clientName.trim().toLowerCase()));
        }
        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<Client> query = session.createQuery(cr);
        List<Client> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another Permission with the same name or apiEndpoint value already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with saving
        session.save(client);
        session.flush();
        session.clear();
        return client;
    }

    @Override
    public Long getAllTotalElements(ClientDto clientDto) {
        Session session = entityManager.unwrap(Session.class);
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Long> cr = cb.createQuery(Long.class);
        Root<Client> root = cr.from(Client.class);

        List<Predicate> andPredicates = new ArrayList<>();

        if (clientDto.getSearchKey() != null) {
            // Filter by name and apiEndpoint using 'like' for partial matching
            Predicate namePredicate = cb.like(
                    cb.lower(root.get("name")),
                    "%" + clientDto.getSearchKey().toLowerCase() + "%"
            );
            andPredicates.add(namePredicate);
        }

        // Add companyId filter
        if (clientDto.getTokenData() != null && clientDto.getTokenData().getCompanyId() != null) {
            Predicate companyIdPredicate = cb.equal(root.get("companyId"), clientDto.getTokenData().getCompanyId());
            andPredicates.add(companyIdPredicate);
        }
        // Build the query and return the count
        cr.select(cb.count(root)).where(cb.and(andPredicates.toArray(new Predicate[] {})));
        Query<Long> query = session.createQuery(cr);
        Long count = query.getSingleResult();

        session.flush();
        session.clear();

        return count;
    }

    @Override
    public List<Client> getAll(ClientDto clientDto) {
        try {
            Session session = entityManager.unwrap(Session.class);
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<Client> cr = cb.createQuery(Client.class);
            Root<Client> root = cr.from(Client.class);

            List<Predicate> andPredicates = new ArrayList<>();

            // Add your search criteria here based on the SearchDto
            if (clientDto.getSearchKey() != null) {
                // Filter by name and apiEndpoint using 'like' for partial matching
                Predicate namePredicate = cb.like(
                        cb.lower(root.get("name")),
                        "%" + clientDto.getSearchKey().toLowerCase() + "%"
                );
                andPredicates.add(namePredicate);
            }

            // Add companyId filter
            if (clientDto.getTokenData() != null && clientDto.getTokenData().getCompanyId() != null) {
                Predicate companyIdPredicate = cb.equal(root.get("companyId"), clientDto.getTokenData().getCompanyId());
                andPredicates.add(companyIdPredicate);
            }

            // Build the query and return the results
            cr.select(root).where(cb.and(andPredicates.toArray(new Predicate[0])));
            cr.orderBy(cb.desc(root.get("id")));
            Query<Client> query = session.createQuery(cr);

            // Apply pagination if required
            if (clientDto.getPageSize() != null && clientDto.getPageNumber() != null && clientDto.getPageNumber() > 0
                    && clientDto.getPageSize() > 0) {
                query.setMaxResults(clientDto.getPageSize());
                query.setFirstResult((clientDto.getPageNumber() - 1) * clientDto.getPageSize());
            }

            List<Client> results = query.getResultList();

            session.flush();
            session.clear();

            return results;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Client findById(Long id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(Client.class, id);
    }
}
