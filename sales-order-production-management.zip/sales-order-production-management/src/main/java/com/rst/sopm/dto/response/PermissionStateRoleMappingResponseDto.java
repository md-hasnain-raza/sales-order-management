package com.rst.sopm.dto.response;

import java.util.Date;

import com.rst.sopm.jwt.IdNameDto;

public class PermissionStateRoleMappingResponseDto {

	private Long id;
	private Long permissionId;
	private Long roleId;
	private Boolean isActive;
	private Date createdOn;
	private Long createdBy;
	private Date updatedOn;
	private Long updatedBy;

	private IdNameDto currentState;
	private IdNameDto nextState;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {

		this.isActive = active;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public IdNameDto getCurrentState() {
		return currentState;
	}

	public void setCurrentState(IdNameDto currentState) {
		this.currentState = currentState;
	}

	public IdNameDto getNextState() {
		return nextState;
	}

	public void setNextState(IdNameDto nextState) {
		this.nextState = nextState;
	}
}
