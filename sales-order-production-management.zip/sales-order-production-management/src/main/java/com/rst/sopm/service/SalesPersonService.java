package com.rst.sopm.service;

import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.jwt.CustomResponse;

public interface SalesPersonService {
    
    CustomResponse saveSalesPerson(SalesPersonDto salesPersonDto);

    CustomResponse updateSalesPerson(SalesPersonDto salesPersonDto);

    CustomResponse getAllSalesPerson(SalesPersonDto salesPersonDto);

    CustomResponse getSalesPerson(SalesPersonDto salesPersonDto);
}
