package com.rst.sopm.jwt;

import java.io.Serializable;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;

	private UserResponseDto userResponseDto;

	private String jwtToken;

	public JwtResponse() {
	}

	public JwtResponse(String jwtToken) {
		this.jwtToken = jwtToken;
	}

	public JwtResponse(UserResponseDto userResponseDto, String jwtToken) {
		this.userResponseDto = userResponseDto;
		this.jwtToken = jwtToken;
	}

	public UserResponseDto getUserResponseDto() {
		return userResponseDto;
	}

	public void setUserResponseDto(UserResponseDto userResponseDto) {
		this.userResponseDto = userResponseDto;
	}

	public String getJwtToken() {
		return jwtToken;
	}

	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
}