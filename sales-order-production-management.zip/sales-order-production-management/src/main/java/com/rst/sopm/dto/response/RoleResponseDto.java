package com.rst.sopm.dto.response;

import com.rst.sopm.jwt.IdNameDto;

import java.util.Date;

public class RoleResponseDto {

	private Long id;
	private String name;
	private String description;
	private Long companyId;
	private Long siteId;
	private Boolean isActive;
	private Date createdOn;
	private IdNameDto createdBy;
	private Date updatedOn;
	private IdNameDto updatedBy;
	private Long permissionCount;

	public RoleResponseDto() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Boolean getActive() {
		return isActive;
	}

	public void setActive(Boolean active) {
		isActive = active;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public IdNameDto getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(IdNameDto createdBy) {
		this.createdBy = createdBy;
	}

	public void setUpdatedBy(IdNameDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}


	public Long getPermissionCount() {
		return permissionCount;
	}

	public void setPermissionCount(Long permissionCount) {
		this.permissionCount = permissionCount;
	}

	public IdNameDto getUpdatedBy() {
		return updatedBy;
	}

}
