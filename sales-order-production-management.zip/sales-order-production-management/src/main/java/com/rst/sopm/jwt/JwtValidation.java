package com.rst.sopm.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.rst.sopm.config.ApiResponseMessagesPropertyConfig;

@Component
@Transactional
public class JwtValidation {

	@Autowired
	private ApiResponseMessagesPropertyConfig responseMessageConfig;

	public CustomResponse validateAuth(JwtRequest requestDTO) {
		if (requestDTO.getEmail() == null || requestDTO.getEmail().isEmpty())
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), false, "Provide Email.");

		if (requestDTO.getPassword() == null || requestDTO.getPassword().isEmpty())
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), false, "Provide Password.");

		return new CustomResponse(HttpStatus.OK.value(), null, HttpStatus.OK.name());
	}

}
