package com.rst.sopm.service;


import com.rst.sopm.dto.CityDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;

public interface CityService {

    CustomResponse saveCity(CityDto cityDto);

    CustomResponse updateCity(CityDto cityDto);

    CustomResponse getAllCities(SearchDto searchDto);
}
