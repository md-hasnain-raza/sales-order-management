package com.rst.sopm.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rst.sopm.config.ApiResponseMessagesPropertyConfig;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("api/v1")
public class JwtAuthenticationController {

	@Autowired
	JwtValidation jwtValidation;
	@Autowired
	UserRepository userRepository;
	@Autowired
	UserService userService;
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsServiceImpl userDetailsService;

	@Autowired
	private ApiResponseMessagesPropertyConfig responseMessageConfig;

	@Autowired
	private EntitySetter entitySetter;
	@Autowired
	private CompanyRepository companyRepository;

	@ApiOperation(value = "Login UserData")
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
		try {
			CustomResponse response = jwtValidation.validateAuth(authenticationRequest);
			if (response.getStatus() == HttpStatus.OK.value()) {
				authenticate(authenticationRequest.getEmail(), authenticationRequest.getPassword());
				CustomUserDetails userDetails = userDetailsService.loadUserByEmail(authenticationRequest.getEmail());
				final String token = jwtTokenUtil.generateToken(userDetails);
				UserResponseDto userResponseDto = userDetailsService
						.loadUserByLoginId(authenticationRequest.getEmail());
				UserData userData = userRepository.findByUserId(userResponseDto.getId());
				userRepository.save(userData);
				Company companyDb = companyRepository.findById(userData.getCompany().getId().longValue()).get();
				userResponseDto.setCompany(new IdNameDto(companyDb.getId().longValue(), companyDb.getName()));
				JwtResponse jwtResponse = new JwtResponse(userResponseDto, token);
				return ResponseEntity.ok(new CustomResponse(HttpStatus.OK.value(), jwtResponse,
						responseMessageConfig.getProperty("Master.GetSuccessMessage")));
			}
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			CustomResponse response2 = new CustomResponse(HttpStatus.UNAUTHORIZED.value(), null,
					"Provide valid credentials.");
			return new ResponseEntity<>(response2, HttpStatus.UNAUTHORIZED);
		}
	}

	private ResponseEntity<CustomResponse> authenticate(String username, String password) throws Exception {
		try {
			Authentication auth = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(username, password));
			CustomResponse response = new CustomResponse();
			if (!auth.isAuthenticated()) {
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.setMessage(HttpStatus.UNAUTHORIZED.toString());
				response.setData(null);
				return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
			} else {
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}

	}

}
