package com.rst.sopm.dao.impl;

import com.rst.sopm.dao.CountryStateDao;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.CountryState;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CountryStateDaoImpl implements CountryStateDao {
    @Autowired
    private EntityManager entityManager;

    @Override
    public CountryState save(CountryState countrystate) {
        Session session = entityManager.unwrap(Session.class);
        session.save(countrystate);
        session.flush();
        return countrystate;
    }

    @Override
    public CountryState update(CountryState countrystate) {
        Session session = entityManager.unwrap(Session.class);
        session.update(countrystate);
        session.flush();
        return countrystate;
    }

    @Override
    public CountryState findById(Long id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(CountryState.class, id);
    }

    @Override
    public List<CountryState> getAll(SearchDto search) {
        Session session = entityManager.unwrap(Session.class);
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<CountryState> cr = cb.createQuery(CountryState.class);
        Root<CountryState> root = cr.from(CountryState.class);

        List<Predicate> andPredicates = new ArrayList<>();

        // Add search criteria based on the SearchDto
        if (search.getSearchKey() != null) {
            Predicate namePredicate = cb.like(cb.lower(root.get("name")), "%" + search.getSearchKey().toLowerCase() + "%");
            andPredicates.add(namePredicate);
        }

        cr.select(root).where(cb.and(andPredicates.toArray(new Predicate[] {})));
        Query<CountryState> query = session.createQuery(cr);

        // Apply pagination if required
        if (search.getPageSize() != null && search.getPageNumber() != null) {
            query.setMaxResults(search.getPageSize());
            query.setFirstResult((search.getPageNumber() - 1) * search.getPageSize());
        }

        List<CountryState> results = query.getResultList();
        session.flush();
        session.clear();

        return results;
    }
}
