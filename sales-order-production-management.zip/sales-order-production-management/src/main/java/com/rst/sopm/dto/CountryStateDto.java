package com.rst.sopm.dto;

public class CountryStateDto {
	private Long id;
	private String name;

	// Default constructor
	public CountryStateDto() {
	}

	// Constructor with all fields
	public CountryStateDto(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	// Getters and setters for each field
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// Optionally, you can override the toString(), equals(), and hashCode() methods

	@Override
	public String toString() {
		return "CountryStateDto{" + "id=" + id + ", name='" + name + '\'' + '}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		CountryStateDto that = (CountryStateDto) o;

		if (id != null ? !id.equals(that.id) : that.id != null)
			return false;
		return name != null ? name.equals(that.name) : that.name == null;
	}

	@Override
	public int hashCode() {
		int result = id != null ? id.hashCode() : 0;
		result = 31 * result + (name != null ? name.hashCode() : 0);
		return result;
	}
}
