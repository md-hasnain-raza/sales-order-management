package com.rst.sopm.controller;

import javax.servlet.http.HttpServletRequest;


import com.rst.sopm.dto.ProductDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;
import com.rst.sopm.jwt.TokenData;
import com.rst.sopm.service.ProductService;
import com.rst.sopm.setter.RequestSetter;
import com.rst.sopm.util.CustomValidation;
import com.rst.sopm.util.LogUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CustomValidation customValidation;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @ApiOperation(value = "Create Product")
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public ResponseEntity<?> createProduct(@RequestBody ProductDto requestDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            requestDto.setTokenData(tokenData);
        }

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.createProduct(requestDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = productService.createProduct(requestDto);
        }

        LOGGER.info(LogUtil.afterExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Get Product")
    @RequestMapping(value = "get", method = RequestMethod.POST)
    public ResponseEntity<?> getProduct(@RequestBody IdNameDto requestDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            requestDto.setTokenData(tokenData);
        }

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getProduct(requestDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = productService.getProduct(requestDto);
        }

        LOGGER.info(LogUtil.afterExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Get All Products")
    @RequestMapping(value = "get/all", method = RequestMethod.POST)
    public ResponseEntity<?> getAllProducts(@RequestBody SearchDto requestDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            requestDto.setTokenData(tokenData);
        }

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getAllProducts(requestDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = productService.getAllProducts(requestDto);
        }

        LOGGER.info(LogUtil.afterExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Update Product")
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public ResponseEntity<?> updateProduct(@RequestBody ProductDto requestDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            requestDto.setTokenData(tokenData);
        }

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.updateProduct(requestDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = productService.updateProduct(requestDto);
        }

        LOGGER.info(LogUtil.afterExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Deactivate Product")
    @RequestMapping(value = "deactivate", method = RequestMethod.POST)
    public ResponseEntity<?> deactivateProduct(@RequestBody IdNameDto requestDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            requestDto.setTokenData(tokenData);
        }

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.deactivateProduct(requestDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = productService.deactivateProduct(requestDto);
        }

        LOGGER.info(LogUtil.afterExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }
}
