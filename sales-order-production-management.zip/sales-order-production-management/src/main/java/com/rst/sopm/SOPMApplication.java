package com.rst.sopm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class SOPMApplication {

	public static void main(String[] args) {
		SpringApplication.run(SOPMApplication.class, args);
	}

}
