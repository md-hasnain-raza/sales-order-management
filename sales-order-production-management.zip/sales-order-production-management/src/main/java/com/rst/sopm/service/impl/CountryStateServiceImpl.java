package com.rst.sopm.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rst.sopm.dao.CountryStateDao;
import com.rst.sopm.dto.CountryStateDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.CountryState;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.service.CountryStateService;

@Service
@Transactional
public class CountryStateServiceImpl implements CountryStateService {
	@Autowired
	private CountryStateDao countrystateDao;

	@Override
	public CustomResponse createCountryState(CountryStateDto countrystateDto) {
		try {
			CountryState countrystate = new CountryState();
			BeanUtils.copyProperties(countrystateDto, countrystate);
			countrystateDao.save(countrystate);
			return new CustomResponse(HttpStatus.OK.value(), countrystateDto, "CountryState created successfully");
		} catch (Exception e) {
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), countrystateDto,
					"Error creating CountryState: " + e.getMessage());
		}
	}

	@Override
	public CustomResponse updateCountryState(CountryStateDto countrystateDto) {
		try {
			CountryState countrystate = countrystateDao.findById(countrystateDto.getId());
			if (countrystate != null) {
				BeanUtils.copyProperties(countrystateDto, countrystate);
				countrystateDao.update(countrystate);
				return new CustomResponse(HttpStatus.OK.value(), countrystateDto, "CountryState updated successfully");
			} else {
				return new CustomResponse(HttpStatus.BAD_REQUEST.value(), countrystateDto, "CountryState not found");
			}
		} catch (Exception e) {
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), countrystateDto,
					"Error updating CountryState: " + e.getMessage());
		}
	}

	@Override
	public CustomResponse getCountryState(Long id) {
		try {
			CountryState countrystate = countrystateDao.findById(id);
			if (countrystate != null) {
				CountryStateDto countrystateDto = new CountryStateDto();
				BeanUtils.copyProperties(countrystate, countrystateDto);
				return new CustomResponse(HttpStatus.OK.value(), countrystateDto, "CountryState found");
			} else {
				return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "CountryState not found");
			}
		} catch (Exception e) {
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
					"Error fetching CountryState: " + e.getMessage());
		}
	}

	@Override
	public CustomResponse getAllCountryStates(SearchDto searchDto) {
		try {
			List<CountryState> countrystates = countrystateDao.getAll(searchDto);
			if (countrystates != null && !countrystates.isEmpty()) {
				List<CountryStateDto> countrystateDtos = countrystates.stream().map(countrystate -> {
					CountryStateDto countrystateDto = new CountryStateDto();
					BeanUtils.copyProperties(countrystate, countrystateDto);
					return countrystateDto;
				}).collect(Collectors.toList());
				return new CustomResponse(HttpStatus.OK.value(), countrystateDtos,
						"CountryStates retrieved successfully");
			} else {
				return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "No CountryStates found");
			}
		} catch (Exception e) {
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
					"Error fetching CountryStates: " + e.getMessage());
		}
	}
}
