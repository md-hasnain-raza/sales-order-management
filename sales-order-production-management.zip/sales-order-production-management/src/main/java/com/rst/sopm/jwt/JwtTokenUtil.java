package com.rst.sopm.jwt;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenUtil implements Serializable {

	// public static final long EXPIRATION_TIME = 100_000;
	public static final long EXPIRATION_TIME = 7 * 24 * 60 * 60;
	public static final String JWT_DELIMITER = "-xXjwt_DelimeterXx-";
	private static final long serialVersionUID = -2550185165626007488L;
	@Value("${jwt.secret}")
	private String secret;

	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getIssuedAtDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getIssuedAt);
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		return expiration.before(new Date());
	}

	private Boolean ignoreTokenExpiration(String token) {
		// here you specify tokens, for that the expiration is ignored
		return false;
	}

	public String generateToken(CustomUserDetails userDetails) {
		Map<String, Object> claims = new HashMap<>();
		return doGenerateToken(claims, userDetails.getEmail() + JWT_DELIMITER + userDetails.getPassword()
				+ JWT_DELIMITER + userDetails.getUserType() + JWT_DELIMITER);
	}

	// while creating the token -
	// 1. Define claims of the token, like Issuer, Expiration, Subject, and the ID
	// 2. Sign the JWT using the HS512 algorithm and secret key.
	// 3. According to JWS Compact
	// Serialization(https://tools.ietf.org/html/draft-ietf-jose-json-web-signature-41#section-3.1)
	// compaction of the JWT to a URL-safe string
	private String doGenerateToken(Map<String, Object> claims, String subject) {

		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME * 1000))
				.signWith(SignatureAlgorithm.HS256, secret).compact();
	}

	public Boolean canTokenBeRefreshed(String token) {
		return (!isTokenExpired(token) || ignoreTokenExpiration(token));
	}

	public Boolean validateToken(String token, CustomUserDetails userDetails) {
		final String usernameWithPasswordAndRoleId = getUsernameFromToken(token);
		String email = null;
		String password = null;
		Integer roleId = null;

		if (usernameWithPasswordAndRoleId != null && usernameWithPasswordAndRoleId.contains(JWT_DELIMITER)) {
			String[] usernamePassCompCode = usernameWithPasswordAndRoleId.split(JWT_DELIMITER);
			email = usernamePassCompCode[0];
			password = usernamePassCompCode[1];
			roleId = Integer.parseInt(usernamePassCompCode[2]);
			if (email != null && password != null) {
				return userDetails.getEmail().equals(email) && userDetails.getUserType().equals(roleId);
			}
			return false;

		}
		return false;
	}
}
