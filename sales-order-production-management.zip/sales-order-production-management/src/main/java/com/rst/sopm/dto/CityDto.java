package com.rst.sopm.dto;


import com.rst.sopm.entity.City;
import com.rst.sopm.jwt.TokenData;



public class CityDto {

    private Long id;
    private String name;
    private boolean isActive;
    private TokenData tokenData;

    public CityDto() {
    }

    public CityDto(String name, boolean isActive) {
        this.name = name;
        this.isActive = isActive;
    }

    public City convertToEntity(CityDto cityDto) {
        City city = new City();
        city.setId(cityDto.getId());
        city.setName(cityDto.getName());
        city.setActive(cityDto.isActive());
        return city;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public TokenData getTokenData() {
        return tokenData;
    }

    public void setTokenData(TokenData tokenData) {
        this.tokenData = tokenData;
    }
}
