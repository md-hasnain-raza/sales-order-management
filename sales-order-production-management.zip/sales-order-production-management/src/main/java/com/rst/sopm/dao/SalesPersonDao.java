package com.rst.sopm.dao;

import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.entity.SalesPerson;


import java.util.List;

public interface SalesPersonDao {

    SalesPerson save(SalesPerson salesPerson);

    List<SalesPerson> getAll(SalesPersonDto salesPersonDto);

    Long getAllTotalElements(SalesPersonDto salesPersonDto);

    SalesPerson findById(Long id);
}
