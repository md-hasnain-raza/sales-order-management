package com.rst.sopm.dto;

public class IdCountDto {

    private Long id;
    private Long count;

    public IdCountDto() {
    }

    public IdCountDto(Long id, Long count) {
        this.id = id;
        this.count = count;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
}
