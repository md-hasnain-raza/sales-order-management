package com.rst.sopm.setter;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.rst.sopm.jwt.CustomUserDetails;
import com.rst.sopm.jwt.TokenData;

@Component
public class RequestSetter {

	public static TokenData getTokenDataFromHttpRequest(HttpServletRequest request) {

		Logger tokenDataFromHttpRequestLogger = LoggerFactory.getLogger(RequestSetter.class);
		try {
			Principal principal = request.getUserPrincipal();
			if (principal != null) {
				final CustomUserDetails currentUser = (CustomUserDetails) ((Authentication) principal).getPrincipal();

				return new TokenData(currentUser.getUserId(), currentUser.getName(), currentUser.getEmail());

			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			tokenDataFromHttpRequestLogger.error(ExceptionUtils.getFullStackTrace(e));
			return null;
		}

	}

}
