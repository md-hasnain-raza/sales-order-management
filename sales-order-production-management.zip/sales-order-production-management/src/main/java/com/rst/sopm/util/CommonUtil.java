package com.rst.sopm.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rst.sopm.dto.response.GroupHierarchyResponseDto;
import com.rst.sopm.dto.response.GroupResponseDto;
import com.rst.sopm.dto.response.PermissionHierarchy;
import com.rst.sopm.dto.response.PermissionResponseDto;

@Transactional
@Component
public class CommonUtil {



}
