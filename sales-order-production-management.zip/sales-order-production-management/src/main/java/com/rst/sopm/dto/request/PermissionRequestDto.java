package com.rst.sopm.dto.request;

import javax.validation.constraints.NotBlank;

import com.rst.sopm.jwt.TokenData;

public class PermissionRequestDto {

	private Long id;
	@NotBlank(message = "Name is required")
	private String name;
	private Long appId;
	private Long groupId;
	@NotBlank(message = "API Endpoint is required")
	private String apiEndpoint;
	private TokenData tokenData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getApiEndpoint() {
		return apiEndpoint;
	}

	public void setApiEndpoint(String apiEndpoint) {
		this.apiEndpoint = apiEndpoint;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}
