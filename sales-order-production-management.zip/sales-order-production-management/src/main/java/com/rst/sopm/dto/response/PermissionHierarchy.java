package com.rst.sopm.dto.response;

import java.util.List;

public class PermissionHierarchy {
	private List<PermissionResponseDto> permissions;
	private List<GroupResponseDto> subgroups;
	private int permissionsCount;
	private int subgroupsCount;

	public List<PermissionResponseDto> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<PermissionResponseDto> permissions) {
		this.permissions = permissions;
	}

	public List<GroupResponseDto> getSubgroups() {
		return subgroups;
	}

	public void setSubgroups(List<GroupResponseDto> subgroups) {
		this.subgroups = subgroups;
	}

	public int getPermissionsCount() {
		return permissionsCount;
	}

	public void setPermissionsCount(int permissionsCount) {
		this.permissionsCount = permissionsCount;
	}

	public int getSubgroupsCount() {
		return subgroupsCount;
	}

	public void setSubgroupsCount(int subgroupsCount) {
		this.subgroupsCount = subgroupsCount;
	}
}