package com.rst.sopm.service;


import com.rst.sopm.dto.ProductDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;

public interface ProductService {
    CustomResponse createProduct(ProductDto productDto);

    CustomResponse getProduct(IdNameDto productId);

    CustomResponse updateProduct(ProductDto productDto);

    CustomResponse deactivateProduct(IdNameDto requestDto);

    CustomResponse getAllProducts(SearchDto requestDto);
}
