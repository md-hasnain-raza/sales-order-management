package com.rst.sopm.jwt;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DateUtil {

	public static Long stringTimeTolong(String time) {
		if (time == null)
			return null;

		return ChronoUnit.MILLIS.between(LocalTime.MIDNIGHT, LocalTime.parse(time));
	}

	public static String dateToTime(Date date) {
		if (date == null)
			return null;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

		return sdf.format(date);
	}

	public static Date dateAfterAddingDays(Date date, int days) {

		if (date == null)
			return null;
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DATE, days);
		return c.getTime();
	}

	public static Date dateAfterAddingMonths(Date date, int months) {
		if (date == null)
			return null;
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, months);
		return c.getTime();
	}

	public static Date dateAfterAddingHours(Date date, int hours) {

		if (date == null)
			return null;
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.HOUR, hours);
		return c.getTime();
	}

	public static Date dateAfterAddingMinutes(Date date, int minute) {

		if (date == null)
			return null;
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MINUTE, minute);
		return c.getTime();
	}

	public static Date dateWithRoundOffTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static Date dateWithoutTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static Date dateWithEndTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static Date nextDateWithoutTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		cal.add(Calendar.DAY_OF_YEAR, 1);
		return cal.getTime();
	}

	public static Date previousDateWithoutTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		cal.add(Calendar.DAY_OF_YEAR, -1);
		return cal.getTime();
	}

	public static Date[] getSameDateTomorrowDateWithoutTime(Date date) {

		if (date == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		Date fromDate = new GregorianCalendar(year, month, day).getTime();
		Date toDate = null;
		if (month == 11 && day == 31)
			toDate = new GregorianCalendar(year + 1, 0, 1).getTime();
		else
			toDate = new GregorianCalendar(year, month, day + 1).getTime();

		Date[] dates = { fromDate, toDate };
		return dates;
	}

	public static Date[] getSameDatePreviousDateWithoutTime(Date date) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		Date toDate = new GregorianCalendar(year, month, day).getTime();
		Date fromDate = null;
		if (month == 0 && day == 1)
			fromDate = new GregorianCalendar(year - 1, 11, 31).getTime();
		else
			fromDate = new GregorianCalendar(year, month, day - 1).getTime();

		Date[] dates = { fromDate, toDate };
		return dates;
	}

	public static Date[] getTomorrowDateNextDateWithoutTime(Date date) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		Date fromDate = null;
		if (month == 11 && day == 31)
			fromDate = new GregorianCalendar(year + 1, 0, 1).getTime();
		else
			fromDate = new GregorianCalendar(year, month, day + 1).getTime();
		Date toDate = nextDateWithoutTime(fromDate);
		Date[] dates = { fromDate, toDate };
		return dates;
	}

	public static Long getDiffYears(Date first, Date last) {
		Long diffInMilliSec = last.getTime() - first.getTime();

		Long years = (diffInMilliSec / (10000L * 60 * 60 * 24 * 365));
		return years;
	}

	public static boolean fromSameMonthAndYear(Date fromDate, Date toDate) {

		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal1.setTime(fromDate);
		cal2.setTime(toDate);
		return cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH)
				&& cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

	}

	public static String getDayMonthYear(Date date, boolean isDayRequired) {

		String stringDate = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		LocalDate currentDate = LocalDate.parse(df.format(date));
		int day = currentDate.getDayOfMonth();
		Month month = currentDate.getMonth();
		int year = currentDate.getYear();
		if (isDayRequired) {
			stringDate = day + "/" + month + "/" + year;
		} else {
			stringDate = month + "-" + year;
		}
		return stringDate;
	}

	public static LocalDate getNextDate(LocalDate localDate, int id) {
		if (id == 0) {
			LocalDate nextDay = localDate.plusDays(1);
			return nextDay;
		}
		if (id == 1) {
			LocalDate nextWeek = localDate.plusWeeks(1);
			return nextWeek;
		}
		if (id == 2) {
			LocalDate nextMonth = localDate.plusMonths(1);
			return nextMonth;
		}
		if (id == 3) {
			LocalDate nextQuarterly = localDate.plusMonths(3);
			return nextQuarterly;
		}
		if (id == 4) {
			LocalDate nextHalfYear = localDate.plusMonths(6);
			return nextHalfYear;
		}
		if (id == 5) {
			LocalDate nextYear = localDate.plusYears(1);
			return nextYear;
		}
		return null;
	}

	public static Date addMinutesToJavaUtilDate(Date date, int minutes) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, minutes);
		date = calendar.getTime();
		return date;
	}

	public static Date addSecondsToJavaUtilDate(Date date, int seconds) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.SECOND, seconds);
		date = calendar.getTime();
		return date;
	}

//    public static String dateToZ(Date date) {
//        long mills = date.getTime();
//        System.out.println(mills);
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date(mills));
//        Date dateFrom = cal.getTime();
//        dateFrom = addMinutesToJavaUtilDate(dateFrom, -Constant.IST_OFFSET_IN_MINUTES);
//        DateFormat df = new SimpleDateFormat(Constant.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_Z);
//        String newDate = df.format(dateFrom);
//        return newDate + "Z";
//    }

	public static String dateToZV2(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
		return sdf.format(date);
	}

	public static Date eventDateToNormalDate(String eventDate) throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date result;
		result = df.parse(eventDate);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		return result;

	}

	public static Date dateTimeStringToDate(String dateTimeString) throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		Date date = df.parse(dateTimeString);
		return date;

	}

}
