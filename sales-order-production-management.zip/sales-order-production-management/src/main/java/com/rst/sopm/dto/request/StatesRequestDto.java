package com.rst.sopm.dto.request;

public class StatesRequestDto {

	private Integer currentPermissionStateId;
	private Integer nextPermissionStateId;

	public Integer getCurrentPermissionStateId() {
		return currentPermissionStateId;
	}

	public void setCurrentPermissionStateId(Integer currentPermissionStateId) {
		this.currentPermissionStateId = currentPermissionStateId;
	}

	public Integer getNextPermissionStateId() {
		return nextPermissionStateId;
	}

	public void setNextPermissionStateId(Integer nextPermissionStateId) {
		this.nextPermissionStateId = nextPermissionStateId;
	}
}
