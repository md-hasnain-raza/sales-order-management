package com.rst.sopm.jwt;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "confirmation_token")
public class ConfirmationToken {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long tokenId;

	@Column(name = "confirmation_token")
	private String confirmationToken;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	// @Column(name = "user_id")
	@OneToOne(targetEntity = UserData.class, fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, name = "user_id")
	private UserData userId;

	@Column(name = "is_expired")
	private Boolean isExpired;
	@Column(name = "expired_on")
	private Date expiredOn;

	public ConfirmationToken(UserData userId) {
		this.userId = userId;
		createdDate = new Date();
		confirmationToken = UUID.randomUUID().toString();
	}

	public ConfirmationToken() {
	}

	public void ConfirmationToken2(UserData user) throws NoSuchAlgorithmException, NoSuchProviderException {
		this.userId = user;
		createdDate = new Date();
		confirmationToken = Sha256Utils.securePassword(user.getName(), user.getEmail());
	}

	public long getTokenId() {
		return tokenId;
	}

	public void setTokenId(long tokenId) {
		this.tokenId = tokenId;
	}

	public String getConfirmationToken() {
		return confirmationToken;
	}

	public void setConfirmationToken(String confirmationToken) {
		this.confirmationToken = confirmationToken;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public UserData getUserId() {
		return userId;
	}

	public void setUserId(UserData userId) {
		this.userId = userId;
	}

	public Boolean getExpired() {
		return isExpired;
	}

	public void setExpired(Boolean expired) {
		isExpired = expired;
	}

	public Date getExpiredOn() {
		return expiredOn;
	}

	public void setExpiredOn(Date expiredOn) {
		this.expiredOn = expiredOn;
	}
}