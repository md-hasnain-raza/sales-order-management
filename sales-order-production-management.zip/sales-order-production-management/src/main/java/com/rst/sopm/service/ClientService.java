package com.rst.sopm.service;

import com.rst.sopm.dto.ClientDto;
import com.rst.sopm.jwt.CustomResponse;

public interface ClientService {

    CustomResponse saveClient(ClientDto clientDto);

    CustomResponse updateClient(ClientDto clientDto);

    CustomResponse getAllClient(ClientDto clientDto);

    CustomResponse getClient(ClientDto clientDto);
}
