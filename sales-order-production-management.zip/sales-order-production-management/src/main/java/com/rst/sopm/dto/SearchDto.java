package com.rst.sopm.dto;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.rst.sopm.jwt.TokenData;

public class SearchDto {

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date toDate;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date fromDate;
	private String subscriptionNum;
	private Integer pageNumber;
	private Integer pageSize;
	private Boolean isValid;
	private Boolean isActive;
	private String sortByField;
	private String searchKey;
	private Long id;
	private Long stateId;
	private Boolean isParent;

	private Boolean isLeafNode;
	private Long appId;
	private Long companyId;
	private Long userId;
	private Long roleId;
	private Long permissionStateId;
	private List<Integer> siteIds;
	private List<Long> companyIds;
	private List<Long> permissionIds;
	private Long permissionId;
	private List<String> subscriptionNumbers;
	private TokenData tokenData;

	private Boolean isSame;
	private Boolean hasPermission;
	private Boolean hasGroup;

	public SearchDto() {
		super();
	}

	public SearchDto(Integer pageNumber, Integer pageSize) {
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
	}

	public String getSubscriptionNum() {
		return subscriptionNum;
	}

	public void setSubscriptionNum(String subscriptionNum) {
		this.subscriptionNum = subscriptionNum;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public String getSortByField() {
		return sortByField;
	}

	public void setSortByField(String sortByField) {
		this.sortByField = sortByField;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public Boolean getIsParent() {
		return isParent;
	}

	public void setIsParent(Boolean parent) {
		this.isParent = parent;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}

	public List<Long> getCompanyIds() {
		return companyIds;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		isActive = active;
	}

	public void setCompanyIds(List<Long> companyIds) {
		this.companyIds = companyIds;
	}

	public List<Integer> getSiteIds() {
		return siteIds;
	}

	public void setSiteIds(List<Integer> siteIds) {
		this.siteIds = siteIds;
	}

	public Long getUserId() {
		return userId;
	}

	public Long getPermissionStateId() {
		return permissionStateId;
	}

	public void setPermissionStateId(Long permissionStateId) {
		this.permissionStateId = permissionStateId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Boolean getIsSame() {
		return isSame;
	}

	public void setIsSame(Boolean same) {
		isSame = same;
	}

	public List<Long> getPermissionIds() {
		return permissionIds;
	}

	public void setPermissionIds(List<Long> permissionIds) {
		this.permissionIds = permissionIds;
	}

	public List<String> getSubscriptionNumbers() {
		return subscriptionNumbers;
	}

	public void setSubscriptionNumbers(List<String> subscriptionNumbers) {
		this.subscriptionNumbers = subscriptionNumbers;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public Boolean getIsLeafNode() {
		return isLeafNode;
	}

	public void setIsLeafNode(Boolean leafNode) {
		isLeafNode = leafNode;
	}

	public Boolean getHasPermission() {
		return hasPermission;
	}

	public void setHasPermission(Boolean hasPermission) {
		this.hasPermission = hasPermission;
	}

	public Boolean getHasGroup() {
		return hasGroup;
	}

	public void setHasGroup(Boolean hasGroup) {
		this.hasGroup = hasGroup;
	}
}
