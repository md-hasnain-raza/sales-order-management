package com.rst.sopm.jwt;

public class CustomResponse {

	private Integer status;

	private Object data;

	private String message;

	private Object error;

	private Long totalElements;

	public CustomResponse() {
		super();
	}

	public CustomResponse(Integer status, Object data, String message) {
		super();
		this.status = status;
		this.data = data;
		this.message = message;
	}

	public CustomResponse(Integer status, Object data, String message, Object error) {
		super();
		this.status = status;
		this.data = data;
		this.message = message;
		this.error = error;
	}

	public CustomResponse(Integer status, Object data, String message, Object error, Long totalElements) {
		this.status = status;
		this.data = data;
		this.message = message;
		this.error = error;
		this.totalElements = totalElements;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getError() {
		return error;
	}

	public void setError(Object error) {
		this.error = error;
	}

	public Long getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(Long totalElements) {
		this.totalElements = totalElements;
	}
}
