package com.rst.sopm.controller;

import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.TokenData;
import com.rst.sopm.service.SalesPersonService;
import com.rst.sopm.setter.RequestSetter;
import com.rst.sopm.util.CustomValidation;
import com.rst.sopm.util.LogUtil;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("api")
public class SalesPersonController {

    @Autowired
    private SalesPersonService salesPersonService;

    @Autowired
    private CustomValidation customValidation;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @ApiOperation("Sales Person Add")
    @PostMapping("/add/sales/person")
    public ResponseEntity<?> addSalesPerson(@RequestBody SalesPersonDto salesPersonDto, HttpServletRequest request){

        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            salesPersonDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.saveSalesPerson(salesPersonDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = salesPersonService.saveSalesPerson(salesPersonDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Update Sales Person")
    @PostMapping("/update/sales/person")
    public ResponseEntity<?> updateSalesPerson(@RequestBody SalesPersonDto salesPersonDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            salesPersonDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.updateSalesPerson(salesPersonDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = salesPersonService.updateSalesPerson(salesPersonDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Get All Sales Person Data")
    @PostMapping("get/all/sales/person")
    public ResponseEntity<?> getAllSalesPerson(@RequestBody SalesPersonDto salesPersonDto, HttpServletRequest request){
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            salesPersonDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getAllSalesPerson(salesPersonDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = salesPersonService.getAllSalesPerson(salesPersonDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);

    }

    @ApiOperation(value = "Get Sales Person")
    @PostMapping("/get/sales/person")
    public ResponseEntity<?> getSalesPerson(@RequestBody SalesPersonDto salesPersonDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            salesPersonDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getSalesPerson(salesPersonDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = salesPersonService.getSalesPerson(salesPersonDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

}
