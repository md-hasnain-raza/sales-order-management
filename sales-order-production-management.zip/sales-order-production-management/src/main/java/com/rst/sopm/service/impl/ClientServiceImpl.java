package com.rst.sopm.service.impl;

import com.rst.sopm.dao.ClientDao;
import com.rst.sopm.dto.ClientDto;
import com.rst.sopm.entity.Client;
import com.rst.sopm.jwt.*;
import com.rst.sopm.service.ClientService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientDao clientDao;

    @Autowired
    private UserServiceImpl userService;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public CustomResponse saveClient(ClientDto clientDto) {

        try {
            UserAddUpdateRequestDto userAddUpdateRequestDto = new UserAddUpdateRequestDto();
            userAddUpdateRequestDto.setUserName(clientDto.getName());
            userAddUpdateRequestDto.setEmail(clientDto.getEmail());
            userAddUpdateRequestDto.setIsActive(true);
            userAddUpdateRequestDto.setUserType(new IdNameDto(1L));
            userAddUpdateRequestDto.setCompanyId(1L);
            userAddUpdateRequestDto.setImageUrl("string");
            userAddUpdateRequestDto.setRoleId(1);
            userAddUpdateRequestDto.setUserCode(null);
            userAddUpdateRequestDto.setUserName("tiranga-lock-admin");
            userAddUpdateRequestDto.setPassword(clientDto.getName()+"12321");
            CustomResponse customResponse =userService.save(userAddUpdateRequestDto);

            if(customResponse.getStatus().equals(HttpStatus.OK.value())){
                Client client =clientDto.convertToEntity(clientDto);
                UserData userData = (UserData) customResponse.getData();
                client.setUserData(userData);
                Client saveClient = clientDao.save(client);
                return new CustomResponse(HttpStatus.OK.value(), saveClient,HttpStatus.OK.getReasonPhrase());
            }

            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,"Client Not save!!");
        }catch (Exception e){
            LOGGER.error("Error Occured While Save the client" + e.getMessage(),e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred !!");
        }
    }

    @Override
    public CustomResponse updateClient(ClientDto clientDto) {
        try {
            Client client= clientDto.convertToEntity(clientDto);
            Client saveClient = clientDao.save(client);
            if (client!=null) {
                return new CustomResponse(HttpStatus.OK.value(), saveClient, "Client updated successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), saveClient, "Client already exists");
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating client: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while updating client");
        }
    }

    @Override
    public CustomResponse getAllClient(ClientDto clientDto) {
        try {
            List<Client> clientList = clientDao.getAll(clientDto);

            if (!clientList.isEmpty()) {
                List<ClientDto> clientDtoList = new ArrayList<>();
                for (Client client : clientList) {
                    ClientDto returnClientDto =client.convertToDto(client);
                    clientDtoList.add(returnClientDto);
                }
                Long totalElement = clientDao.getAllTotalElements(clientDto);
                return new CustomResponse(HttpStatus.OK.value(), clientDtoList,
                        "Client Details retrieved successfully",null,totalElement);
            } else {
                return new CustomResponse(HttpStatus.NOT_FOUND.value(), null, "No CLient Details found");
            }

        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching the data: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while fetching the data");
        }
    }

    @Override
    public CustomResponse getClient(ClientDto clientDto) {
        try {
            Client client= clientDao.findById(clientDto.getId());
            if (client!=null) {
                ClientDto returnClientDto=client.convertToDto(client);
                return new CustomResponse(HttpStatus.OK.value(), returnClientDto, "Client retrieved successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "No data found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting Client: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while getting Client");
        }
    }

}
