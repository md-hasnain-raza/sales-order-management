package com.rst.sopm.dto.response;

import java.util.Date;

import com.rst.sopm.jwt.IdNameDto;

public class PermissionStateResponseDto {

	private Long id;
	private Long permissionId;
	private IdNameDto stateId;
	private Boolean isActive;
	private Boolean isFinal;
	private Date createdOn;
	private Long createdBy;
	private Date updatedOn;
	private Long updatedBy;

	// Constructors, getters, and setters

	public PermissionStateResponseDto() {
	}

	public PermissionStateResponseDto(Long id, Long permissionId, IdNameDto stateId, Boolean isActive, Boolean isFinal,
			Date createdOn, Long createdBy, Date updatedOn, Long updatedBy) {
		this.id = id;
		this.permissionId = permissionId;
		this.stateId = stateId;
		this.isActive = isActive;
		this.isFinal = isFinal;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public IdNameDto getStateId() {
		return stateId;
	}

	public void setStateId(IdNameDto stateId) {
		this.stateId = stateId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		isActive = active;
	}

	public Boolean getIsFinal() {
		return isFinal;
	}

	public void setIsFinal(Boolean isFinal) {
		this.isFinal = isFinal;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}
}
