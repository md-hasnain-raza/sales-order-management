package com.rst.sopm.util;

import com.rst.sopm.dto.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.rst.sopm.dto.request.AddRolePermissionMappingRequestDto;
import com.rst.sopm.dto.request.GetPermissionGroupHierarchyRequestDto;
import com.rst.sopm.dto.request.GroupRequestDto;
import com.rst.sopm.dto.request.PermissionGroupMappingRequestDto;
import com.rst.sopm.dto.request.PermissionRequestDto;
import com.rst.sopm.dto.request.PermissionStateRequestDto;
import com.rst.sopm.dto.request.PermissionStateRoleMappingRequestDto;
import com.rst.sopm.dto.request.RoleRequestDto;
import com.rst.sopm.dto.request.StateRequestDto;
import com.rst.sopm.dto.request.UpdateRolePermissionRequestDto;
import com.rst.sopm.dto.request.UserRoleMappingRequestDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;

@Component
@Transactional
public class CustomValidation {

	// Add any required dependencies

	public CustomResponse createPermission(PermissionRequestDto requestDto) {
		if (requestDto.getName() == null || requestDto.getName().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Name is required.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermission(IdNameDto requestDto) {
		// Add your validation logic here for getting a permission
		// Example: Check if the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission ID.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissions(SearchDto requestDto) {
		// Add your validation logic here for getting all permissions
		// Example: Check if pagination parameters are valid
		if (requestDto.getPageNumber() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page number.");
		}

		if (requestDto.getPageSize() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page size.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updatePermission(PermissionRequestDto requestDto) {
		// Add your validation logic here for updating a permission
		// Example: Check if required fields are provided and the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission ID.");
		}

		if (requestDto.getName() == null || requestDto.getName().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Name is required.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivatePermission(IdNameDto requestDto) {
		// Add your validation logic here for deactivating a permission
		// Example: Check if the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission ID.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse addPermissionGroupMapping(PermissionGroupMappingRequestDto requestDto) {
		// Add your validation logic here for adding a permission group mapping
		// Example: Check if required fields are provided

		if (requestDto.getGroupId() == null || requestDto.getGroupId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Group ID is required.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updatePermissionGroupMapping(PermissionGroupMappingRequestDto requestDto) {
		// Add your validation logic here for updating a permission group mapping
		// Example: Check if required fields are provided and the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission group mapping ID.");
		}

		if (requestDto.getGroupId() == null || requestDto.getGroupId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Group ID is required.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermissionGroupMapping(IdNameDto requestDto) {
		// Add your validation logic here for getting a permission group mapping
		// Example: Check if the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission group mapping ID.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissionGroupMappings(SearchDto requestDto) {
		// Add your validation logic here for getting all permission group mappings
		// Example: Check if pagination parameters are valid
		if (requestDto.getPageNumber() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page number.");
		}

		if (requestDto.getPageSize() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page size.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivatePermissionGroupMapping(IdNameDto requestDto) {
		// Add your validation logic here for deactivating a permission group mapping
		// Example: Check if the ID is valid
		if (requestDto.getId() == null || requestDto.getId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid permission group mapping ID.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse createPermissionGroup(GroupRequestDto requestDto) {

		if (requestDto.getName() == null) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide Name.");
		}

		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermissionGroup(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissionGroups(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updatePermissionGroup(GroupRequestDto requestDto) {
		if (requestDto.getName() == null) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide Name.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivatePermissionGroup(IdNameDto requestDto) {
		if (requestDto.getId() == null) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide Id.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse createRole(RoleRequestDto requestDto) {
		// Add your validation logic here for creating a role
		// Example: Check if the name is not empty
		if (requestDto.getName() == null || requestDto.getName().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Name cannot be empty.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updateRole(RoleRequestDto requestDto) {
		// Add your validation logic here for updating a role
		// Example: Check if the name is not empty
		if (requestDto.getName() == null || requestDto.getName().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Name cannot be empty.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivateRole(IdNameDto requestDto) {
		// Add your validation logic here for deactivating a role
		// Example: Check if the role exists or is already deactivated

		// You can add your specific validation logic here

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getRole(IdNameDto requestDto) {
		// Add your validation logic here for retrieving a role
		// Example: Check if the role exists

		// You can add your specific validation logic here

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllRoles(SearchDto requestDto) {
		// Add your validation logic here for retrieving all roles
		// Example: Check if pagination parameters are valid
		if (requestDto.getPageNumber() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page number.");
		}

		if (requestDto.getPageSize() < 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid page size.");
		}

		// Additional validation logic if needed

		// Return OK response if all validations pass
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermissionGroupHierarchy(GetPermissionGroupHierarchyRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse addState(StateRequestDto requestDto) {
		if (requestDto.getName() == null || requestDto.getName().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid Name.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllState(StateRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse addRolePermissionMapping(AddRolePermissionMappingRequestDto requestDto) {
		if (requestDto.getRoleId() == null || requestDto.getRoleId() <= 0) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid Role ID.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissionHierarchyByRoleId(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateCreateUserRoleMappingRequest(UserRoleMappingRequestDto requestDto) {
		if (requestDto.getUserId() == null || requestDto.getUserId() < 1) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide user Id.");
		}
		if (requestDto.getRoleIds() == null || requestDto.getRoleIds().isEmpty()) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide Role Ids.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateUpdateUserRoleMappingRequest(UserRoleMappingRequestDto requestDto) {
		if (requestDto.getIsActive() == null) {
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Provide status.");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updateRolePermissionMapping(UpdateRolePermissionRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivateRolePermissionMapping(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllUserRoleMapping(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivateUserRoleMapping(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getUserRoleMapping(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermissionStateRoleMapping(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissionStateRoleMapping(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateUpdatePermissionStateRoleMappingRequest(
			PermissionStateRoleMappingRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivatePermissionStateRoleMapping(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateCreatePermissionStateRoleMappingRequest(
			PermissionStateRoleMappingRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivatePermissionState(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateUpdatePermissionStateRequest(PermissionStateRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllPermissionStates(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getPermissionState(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse validateCreatePermissionStateRequest(PermissionStateRequestDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

    public CustomResponse createApp(AppDto appDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
    }

	public CustomResponse getApp(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updateApp(AppDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivateApp(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllApp(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

    public CustomResponse saveClient(ClientDto clientDto) {
		if(clientDto.getName() == null){
			return new CustomResponse(HttpStatus.NO_CONTENT.value(),null,"Name cannot be null !!");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
    }

	public CustomResponse updateClient(ClientDto clientDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}


	public CustomResponse getAllClient(ClientDto clientDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse saveSalesPerson(SalesPersonDto salesPersonDto) {
		if(salesPersonDto.getName() == null){
			return new CustomResponse(HttpStatus.NO_CONTENT.value(),null,"Name cannot be null !!");
		}
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updateSalesPerson(SalesPersonDto salesPersonDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllSalesPerson(SalesPersonDto salesPersonDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getClient(ClientDto clientDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getSalesPerson(SalesPersonDto salesPersonDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse createProduct(ProductDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getProduct(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse getAllProducts(SearchDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse deactivateProduct(IdNameDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}

	public CustomResponse updateProduct(ProductDto requestDto) {
		return new CustomResponse(HttpStatus.OK.value(), null, "Validation passed.");
	}
}
