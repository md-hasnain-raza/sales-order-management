package com.rst.sopm.jwt;

public class EmailConstant {

	public final static String Forget_Email_User_Subject = "Reset Password Request";
	public final static String Device_Request = "Request For Digi Lock";

	public final static String Company_Register_Subject = "Welcome to Digital Lock Management Service,";
	public final static String Consignee_Register_Subject = "Consignee Register Credentials";
	public final static String Driver_Register_Subject = "Registered Driver Credentials";

	public static String getForgerPasswordContent(String userName, ConfirmationToken confirmationToken) {
		String content = "<!DOCTYPE html>\n" + "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" + "  <head>\n"
				+ "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" + "  </head>\n"
				+ "  <body>\n" + "    <div style=\"font-family: Roboto\">\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n" + "        <img\n"
				+ "          src=\"https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B\"\n"
				+ "          alt=\"Rapidsoft Technologies Pvt. Ltd.\"\n"
				+ "          style=\"width: 5vw; height: 7vh; margin: 0px; padding: 0px\"\n" + "        />\n"
				+ "        <b\n" + "          style=\"\n" + "            margin-left: 2vw;\n"
				+ "            font-size: 35px;\n" + "            font-weight: bold;\n"
				+ "            margin-top: 1vw;\n" + "            color: #3f4863;\n" + "          \"\n"
				+ "          >RapidSoft Technologies Pvt. Ltd.</b\n" + "        >\n" + "      </div>\n"
				+ "      <p style=\"font-size: 20px;\">Hello, <b style=\"color: #3f4863\">" + userName + "</b></p>\n"
				+ "      <p style=\"font-size: 18px\">To complete the password reset process</p>\n"
				+ "      <div style=\"padding: 0; margin: 0; display: flex; flex-direction: row\">\n"
				+ "        <p style=\"font-size: 18px; font-weight: bold;\">Click here to Reset</p>\n"
				+ "        <a href=\"http://j1dev.nyggs.com/resetPassword?token="
				+ confirmationToken.getConfirmationToken() + "\">\n" + "        <button\n" + "          style=\"\n"
				+ "            width: 80px;\n" + "            height: 40px;\n" + "            border-radius: 8px;\n"
				+ "            background-color: #556ee6;\n" + "            color: white;\n"
				+ "            font-size: 18px;\n" + "            font-family: Roboto;\n"
				+ "            border: none;\n" + "            margin-left: 10px;\n"
				+ "            box-shadow: 1px 1px 3px rgb(155, 154, 154);\n" + "            margin-top: 8px;\n"
				+ "          \"\n" + "        >\n" + "          Reset\n" + "        </button>\n" + "        </a>\n"
				+ "      </div>\n"
				+ "      <p style=\"font-size: 16px;  padding: 0; margin: 0;margin-top: 20px;\">Thanks</p>\n"
				+ "      <p style=\"font-size: 16px; padding: 0; margin: 0;\">Team DLMS-Rapidsoft</p>\n"
				+ "    </div>\n" + "  </body>\n" + "</html>";
		return content;
	}

	public static String getRegisterCompanyContent(String companyName, String userCode, String passcode,
			ConfirmationToken confirmationToken) {
		String content = "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" + "  <head>\n"
				+ "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n"
				+ "    <!-- <title>Welcome Mail</title> -->\n" + "  </head>\n" + "\n" + "  <body>\n"
				+ "    <div style=\"font-family: Roboto\">\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n" + "        <img\n"
				+ "          src=\"https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B\"\n"
				+ "          alt=\"Rapidsoft Technologies Pvt. Ltd.\"\n"
				+ "          style=\"width: 5vw; height: 7vh; margin: 0px; padding: 0px\"\n" + "        />\n"
				+ "        <b\n" + "          style=\"\n" + "            margin-left: 2vw;\n"
				+ "            font-size: 35px;\n" + "            font-weight: bold;\n"
				+ "            margin-top: 1vw;\n" + "            color: #3f4863;\n" + "          \"\n"
				+ "          >RapidSoft Technologies Pvt. Ltd.</b\n" + "        >\n" + "      </div>\n"
				+ "      <div>\n" + "        <p style=\" font-size: 20px\">\n"
				+ "          Hello, <b style=\"color: #3f4863\">" + companyName + "</b>\n" + "        </p>\n"
				+ "        <p style=\"font-size: 24px\">\n"
				+ "          Welcome to <b style=\"color: #3f4863\">DLMS</b> of <b style=\"color: #3f4863\">Rapidsoft</b>\n"
				+ "        </p>\n" + "        <p style=\"font-size: 18px\">\n"
				+ "          Please find your credentials to login to our system.\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          We advice you to change your password.\n"
				+ "        </p>\n" + "        <p style=\"font-size: 18px\">\n"
				+ "          Username: <b style=\"color: #3f4863\"> " + userCode + "</b>\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          Password: <b style=\"color: #3f4863\">"
				+ passcode + "</b>\n" + "        </p>\n" + "      </div>\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n"
				+ "        <p style=\"font-size: 18px; font-weight: bold\">\n"
				+ "          Click here to change password\n" + "        </p>\n"
				+ "        <a href=\"http://j1dev.nyggs.com/resetPassword?token="
				+ confirmationToken.getConfirmationToken() + "\">\n" + "        <button\n" + "          style=\"\n"
				+ "            background-color: #556ee6;\n" + "            border: none;\n"
				+ "            width: 150px;\n" + "            height: 40px;\n" + "            color: white;\n"
				+ "            font-size: 15px;\n" + "            border-radius: 10px;\n"
				+ "            margin-left: 10px;\n" + "            margin-top: 8px;\n" + "          \"\n"
				+ "        >\n" + "          Change Password\n" + "        </button>\n" + "	</a>\n" + "      </div>\n"
				+ "	  <div>\n"
				+ "		<p style=\" font-size: 18px; padding-bottom: 0; margin-bottom: 0;\">Thanks</p>\n"
				+ "		<p style=\" font-size: 18px; padding: 0; margin-top: 0;\">Team DLMS-Rapidsoft</p>\n"
				+ "	  </div>\n" + "    </div>\n" + "  </body>\n" + "</html>";
		return content;
	}

	public static String getConsigneeContent(String name, String email, String password) {
		String content = "<!DOCTYPE html>\n" + "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" + "  <head>\n"
				+ "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n"
				+ "    <!-- <title>Welcome Mail</title> -->\n" + "  </head>\n" + "\n" + "  <body>\n"
				+ "    <div style=\"font-family: Roboto\">\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n" + "        <img\n"
				+ "          src=\"https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B\"\n"
				+ "          alt=\"Rapidsoft Technologies Pvt. Ltd.\"\n"
				+ "          style=\"width: 5vw; height: 7vh; margin: 0px; padding: 0px\"\n" + "        />\n"
				+ "        <b\n" + "          style=\"\n" + "            margin-left: 2vw;\n"
				+ "            font-size: 35px;\n" + "            font-weight: bold;\n"
				+ "            margin-top: 1vw;\n" + "            color: #3f4863;\n" + "          \"\n"
				+ "          >RapidSoft Technologies Pvt. Ltd.</b\n" + "        >\n" + "      </div>\n"
				+ "      <div>\n" + "        <p style=\" font-size: 20px\">\n"
				+ "          Hello, <b style=\"color: #3f4863\">" + name + "</b>\n" + "        </p>\n"
				+ "        <!-- <p style=\"font-size: 24px\">\n"
				+ "          Welcome to <b style=\"color: #3f4863\">DLMS</b> of <b style=\"color: #3f4863\">Rapidsoft</b>\n"
				+ "        </p> -->\n" + "        <p style=\"font-size: 18px\">\n"
				+ "        Please find your credentials to login to our system.\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          We advice you to change your password.\n"
				+ "        </p>\n" + "        <p style=\"font-size: 18px\">\n"
				+ "          Username: <b style=\"color: #3f4863\">" + email + "</b>\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          Password: <b style=\"color: #3f4863\">"
				+ password + "</b>\n" + "        </p>\n" + "      </div>\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n"
				+ "        <p style=\"font-size: 18px; font-weight: bold\">\n" + "          Click here to Login\n"
				+ "        </p>\n" + "		<a href=\"http://j1dev.nyggs.com\">\n" + "        <button\n"
				+ "          style=\"\n" + "            background-color: #556ee6;\n" + "            border: none;\n"
				+ "            width: 150px;\n" + "            height: 40px;\n" + "            color: white;\n"
				+ "            font-size: 15px;\n" + "            border-radius: 10px;\n"
				+ "            margin-left: 10px;\n" + "            margin-top: 8px;\n" + "          \"\n"
				+ "        >\n" + "          Login\n" + "        </button>\n" + "	</a>\n" + "      </div>\n"
				+ "	  <div>\n"
				+ "		<p style=\" font-size: 18px; padding-bottom: 0; margin-bottom: 0;\">Thanks</p>\n"
				+ "		<p style=\" font-size: 18px; padding: 0; margin-top: 0;\">Team DLMS-Rapidsoft</p>\n"
				+ "	  </div>\n" + "    </div>\n" + "  </body>\n" + "</html>";
		return content;
	}

	public static String getDriverContent(String name, String email, String password) {
		String content = "<!DOCTYPE html>\n" + "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" + "  <head>\n"
				+ "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n"
				+ "    <!-- <title>Welcome Mail</title> -->\n" + "  </head>\n" + "\n" + "  <body>\n"
				+ "    <div style=\"font-family: Roboto\">\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n" + "        <img\n"
				+ "          src=\"https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B\"\n"
				+ "          alt=\"Rapidsoft Technologies Pvt. Ltd.\"\n"
				+ "          style=\"width: 5vw; height: 7vh; margin: 0px; padding: 0px\"\n" + "        />\n"
				+ "        <b\n" + "          style=\"\n" + "            margin-left: 2vw;\n"
				+ "            font-size: 35px;\n" + "            font-weight: bold;\n"
				+ "            margin-top: 1vw;\n" + "            color: #3f4863;\n" + "          \"\n"
				+ "          >RapidSoft Technologies Pvt. Ltd.</b\n" + "        >\n" + "      </div>\n"
				+ "      <div>\n" + "        <p style=\" font-size: 20px\">\n"
				+ "          Hello, <b style=\"color: #3f4863\">" + name + "</b>\n" + "        </p>\n"
				+ "        <!-- <p style=\"font-size: 24px\">\n"
				+ "          Welcome to <b style=\"color: #3f4863\">DLMS</b> of <b style=\"color: #3f4863\">Rapidsoft</b>\n"
				+ "        </p> -->\n" + "        <p style=\"font-size: 18px\">\n"
				+ "        Please find your credentials to login to our system.\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          We advice you to change your password.\n"
				+ "        </p>\n" + "        <p style=\"font-size: 18px\">\n"
				+ "          Username: <b style=\"color: #3f4863\">" + email + "</b>\n" + "        </p>\n"
				+ "        <p style=\"font-size: 18px\">\n" + "          Password: <b style=\"color: #3f4863\">"
				+ password + "</b>\n" + "        </p>\n" + "      </div>\n"
				+ "      <div style=\"display: flex; flex-direction: row\">\n"
				+ "        <p style=\"font-size: 18px; font-weight: bold\">\n" + "          Click here to Login\n"
				+ "        </p>\n" + "		<a href=\"http://j1dev.nyggs.com\">\n" + "        <button\n"
				+ "          style=\"\n" + "            background-color: #556ee6;\n" + "            border: none;\n"
				+ "            width: 150px;\n" + "            height: 40px;\n" + "            color: white;\n"
				+ "            font-size: 15px;\n" + "            border-radius: 10px;\n"
				+ "            margin-left: 10px;\n" + "            margin-top: 8px;\n" + "          \"\n"
				+ "        >\n" + "          Login\n" + "        </button>\n" + "	</a>\n" + "      </div>\n"
				+ "	  <div>\n"
				+ "		<p style=\" font-size: 18px; padding-bottom: 0; margin-bottom: 0;\">Thanks</p>\n"
				+ "		<p style=\" font-size: 18px; padding: 0; margin-top: 0;\">Team DLMS-Rapidsoft</p>\n"
				+ "	  </div>\n" + "    </div>\n" + "  </body>\n" + "</html>";

		return content;
	}

	public static String getSubscriptionStatusUpdate(String companyName, String contactPersonName,
			String subscriptionEndDate) {
		String content = "<html xmlns='http://www.w3.org/1999/xhtml'>\n" + "\n" + "<head>\n"
				+ "    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\n" + "</head>\n" + "\n"
				+ "<body>\n" + "    <div style='font-family: Roboto'>\n"
				+ "        <div style='display: flex; flex-direction: row'>\n"
				+ "            <img src='https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B'\n"
				+ "                alt='Rapidsoft Technologies Pvt. Ltd.' style='width: 5vw; height: 7vh; margin: 0px; padding: 0px' />\n"
				+ "            <b style='\n" + "                    margin-left: 2vw;\n"
				+ "                    font-size: 35px;\n" + "                    font-weight: bold;\n"
				+ "                    margin-top: 1vw;\n" + "                    color: #3f4863;\n"
				+ "                    '>RapidSoft Technologies Pvt. Ltd.</b>\n" + "        </div>\n"
				+ "        <div>\n" + "            <p style=' font-size: 20px'>\n"
				+ "                Dear, <b style='color: #3f4863'>" + companyName + "</b>\n" + "            </p>\n"
				+ "            <p style=' font-size: 20px'>\n"
				+ "                Kind attn : <b style='color: #3f4863'>" + contactPersonName + "</b>\n"
				+ "            </p>\n" + "            <blockquote style='font-size: 24px'>\n"
				+ "                This is to inform you that the following lock subscription is about to end on date\n"
				+ "                <b>" + subscriptionEndDate + "</b>.\n" + "            </blockquote>\n"
				+ "            <p style=\"font-size: 24px\">\n"
				+ "                Your locks will cease to work after expiry date.</p>\n"
				+ "            <blockquote style='font-size: 24px'>\n" + "                Kindly renew you\n"
				+ "                lock subscription on or before <b>" + subscriptionEndDate
				+ "</b> enjoy uninteruppted\n" + "                service.\n" + "            </blockquote>\n"
				+ "            <p style='font-size: 18px'>\n"
				+ "                For any query related to the subscription you can reach us.<br/>Email  :  <b\n"
				+ "                    style='color: #3f4863'>sales@rapidsofttechnologies.com</b>\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n" + "                Thanks\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n"
				+ "                Customer support<br />\n" + "                From <br />\n"
				+ "                Team DLMS\n" + "            </p>\n" + "        </div>\n" + "\n" + "    </div>\n"
				+ "</body>\n" + "\n" + "</html>";
		return content;
	}

	public static String getSubscriptionStatusEnd(String companyName, String contactPersonName,
			String subscriptionEndDate) {
		String content = "<html xmlns='http://www.w3.org/1999/xhtml'>\n" + "\n" + "<head>\n"
				+ "    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\n" + "</head>\n" + "\n"
				+ "<body>\n" + "    <div style='font-family: Roboto'>\n"
				+ "        <div style='display: flex; flex-direction: row'>\n"
				+ "            <img src='https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B'\n"
				+ "                alt='Rapidsoft Technologies Pvt. Ltd.' style='width: 5vw; height: 7vh; margin: 0px; padding: 0px' />\n"
				+ "            <b style='\n" + "                    margin-left: 2vw;\n"
				+ "                    font-size: 35px;\n" + "                    font-weight: bold;\n"
				+ "                    margin-top: 1vw;\n" + "                    color: #3f4863;\n"
				+ "                    '>RapidSoft Technologies Pvt. Ltd.</b>\n" + "        </div>\n"
				+ "        <div>\n" + "            <p style=' font-size: 20px'>\n"
				+ "                Dear, <b style='color: #3f4863'>" + companyName + "</b>\n" + "            </p>\n"
				+ "            <p style=' font-size: 20px'>\n"
				+ "                Kind attn : <b style='color: #3f4863'>" + contactPersonName + "</b>\n"
				+ "            </p>\n" + "            <p style=' font-size: 20px'>\n"
				+ "               	 Your subscription for the following lock had been expired on this\n"
				+ "                <b>" + subscriptionEndDate + "</b>.\n" + "                <br />\n"
				+ "                Your locks will cease to work after expiry date.\n" + "            </p>\n"
				+ "            <p style='font-size: 18px'>\n"
				+ "               	 Kindly renew in as earlier to enjoy uninterrupted service.\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n"
				+ "                For any query related to the subscription you can reach us.<br />Email : <b\n"
				+ "                    style='color: #3f4863'>sales@rapidsofttechnologies.com</b>\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n" + "                Thanks\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n"
				+ "                Customer support<br />\n" + "                From <br />\n"
				+ "                Team DLMS\n" + "            </p>\n" + "        </div>\n" + "\n" + "    </div>\n"
				+ "</body>\n" + "\n" + "</html>";
		return content;
	}

	public static String getSubscriptionNoOfTripFinish(String companyName, String contactPersonName, String noOfTrip) {
		String content = "<html xmlns='http://www.w3.org/1999/xhtml'>\n" + "\n" + "<head>\n"
				+ "    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\n" + "</head>\n" + "\n"
				+ "<body>\n" + "    <div style='font-family: Roboto'>\n"
				+ "        <div style='display: flex; flex-direction: row'>\n"
				+ "            <img src='https://clutchco-static.s3.amazonaws.com/s3fs-public/logos/logo_64.png?VersionId=eSIsKfp_4jiwLnLKQ7G2sF9Lpz_e7M7B'\n"
				+ "                alt='Rapidsoft Technologies Pvt. Ltd.' style='width: 5vw; height: 7vh; margin: 0px; padding: 0px' />\n"
				+ "            <b style='\n" + "                    margin-left: 2vw;\n"
				+ "                    font-size: 35px;\n" + "                    font-weight: bold;\n"
				+ "                    margin-top: 1vw;\n" + "                    color: #3f4863;\n"
				+ "                    '>RapidSoft Technologies Pvt. Ltd.</b>\n" + "        </div>\n"
				+ "        <div>\n" + "            <p style=' font-size: 20px'>\n"
				+ "                Dear, <b style='color: #3f4863'>" + companyName + "</b>\n" + "            </p>\n"
				+ "            <p style=' font-size: 20px'>\n"
				+ "                Kind attn : <b style='color: #3f4863'>" + contactPersonName + "</b>\n"
				+ "            </p>\n" + "            <p style='font-size: 24px'>\n"
				+ "               	 This is to inform you that you have only <b>" + noOfTrip
				+ "</b> number of trips left for use.\n" + "                <br />\n"
				+ "                In case you want to use our service please renew for more trips.\n"
				+ "            </p>\n" + "            <p style='font-size: 24px'>\n"
				+ "                Locks will cease to work once you complete the number of trips assigned to you.\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n"
				+ "                For any query related to the subscription you can reach us.<br />Email : <b\n"
				+ "                    style='color: #3f4863'>sales@rapidsofttechnologies.com</b>\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n" + "                Thanks\n"
				+ "            </p>\n" + "            <p style='font-size: 18px'>\n"
				+ "                Customer support<br />\n" + "                From <br />\n"
				+ "                Team DLMS\n" + "            </p>\n" + "        </div>\n" + "\n" + "    </div>\n"
				+ "</body>\n" + "\n" + "</html>";
		return content;
	}

	public static String DeviceRequest(String serialNumber, String requestTypeName, String requestId,
			String companyName, String userName) {
		String content = "<!DOCTYPE html>\n" + "<html>\n" + "  <head>\n" + "    <meta charset=\"UTF-8\">\n"
				+ "    <title>Device " + requestTypeName + " Request Update</title>\n" + "  </head>\n" + "  <body>\n"
				+ "    <p>Dear " + userName + ",</p>\n"
				+ "    <p>We hope this email finds you well. We are writing to update you on your recent request for device replacement.</p>\n"
				+ "    <p>Your request with ID " + requestId + " and Serial Number " + serialNumber + " for "
				+ requestTypeName
				+ " has been received and is currently being processed by our team. We understand the importance of having a fully functioning device and we are committed to resolving this issue for you as quickly as possible.</p>\n"
				+ "    <p>Our team is working diligently to ensure that your replacement device is delivered to you in a timely manner. We will keep you updated on the progress of your request, and we appreciate your patience during this time.</p>\n"
				+ "    <p>If you have any questions or concerns regarding your request, please do not hesitate to contact our customer support team. We are always here to assist you.</p>\n"
				+ "    <p>Thank you for choosing our company. We appreciate your business and look forward to serving you in the future.</p>\n"
				+ "    <p>Best regards,<br>" + companyName + "</p>\n" + "  </body>\n" + "</html>\n";
		return content;
	}

	public static String updateRequestStatus(String requestId, String newStatus, String serialNumber,
			String companyName) {
		String content = "<!DOCTYPE html>\n" + "<html>\n" + "  <head>\n" + "    <meta charset=\"UTF-8\">\n"
				+ "    <title>Request " + requestId + " Update</title>\n" + "  </head>\n" + "  <body>\n"
				+ "    <p>Dear User,</p>\n"
				+ "    <p>We are writing to inform you of an update regarding your request with ID " + requestId
				+ " and Serial Number " + serialNumber + ".</p>\n" + "    <p>The current status of your request is: "
				+ newStatus + ".</p>\n"
				+ "    <p>If you have any questions or concerns regarding your request, please do not hesitate to contact our customer support team. We are always here to assist you.</p>\n"
				+ "    <p>Thank you for choosing our company. We appreciate your business and look forward to serving you in the future.</p>\n"
				+ "    <p>Best regards,<br>" + companyName + "</p>\n" + "  </body>\n" + "</html>\n";

		return content;
	}

}
