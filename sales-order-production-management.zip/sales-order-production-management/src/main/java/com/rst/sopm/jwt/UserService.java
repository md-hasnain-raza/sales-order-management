package com.rst.sopm.jwt;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public interface UserService {

	CustomResponse updateUserPassword(UserPasswordUpdateRequestDto requestDto);

	CustomResponse forgetPassword(String email) throws NoSuchAlgorithmException, NoSuchProviderException;

	CustomResponse resetPassword(JwtRequest jwtRequest);

	CustomResponse save(UserAddUpdateRequestDto requestDto);

	CustomResponse getUser(IdNameDto idNameDto);
}
