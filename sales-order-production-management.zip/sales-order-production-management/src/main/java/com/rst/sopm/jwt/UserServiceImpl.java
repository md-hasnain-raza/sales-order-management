package com.rst.sopm.jwt;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.rst.sopm.config.ApiResponseMessagesPropertyConfig;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ApiResponseMessagesPropertyConfig responseMessagesPropertyConfig;
	@Autowired
	UserDao userDao;

	@Autowired
	EntitySetter entitySetter;
	@Autowired
	EmailService emailService;
	@Autowired
	ConfirmationTokenRepository confirmationTokenRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Value("${spring.mail.host}")
	private String host;

	@Value("${spring.mail.port}")
	private String port;

	@Value("${spring.mail.username}")
	private String username;

	@Value("${spring.mail.password}")
	private String password;

	@Autowired
	private ApiResponseMessagesPropertyConfig responseMessageConfig;

	@Autowired
	private JwtValidation jwtValidation;

	@Override
	public CustomResponse save(UserAddUpdateRequestDto userAddUpdateRequestDto) {
		try {
			UserData newUser = entitySetter.userAddUpdateDtoUserDb(userAddUpdateRequestDto);
			UserData userData = userDao.saveUser(newUser);
			if (userData != null) {
				return new CustomResponse(HttpStatus.OK.value(), userData, "UserData Added Successfully");
			}
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "UserData Already Exists");
		} catch (Exception e) {

			LOGGER.error("Error in save UserData", e.getCause());
			e.printStackTrace();
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, e.getMessage());
		}
	}

	@Override
	public CustomResponse updateUserPassword(UserPasswordUpdateRequestDto requestDto) {
		try {
			UserData userData = userRepository.findByUserId(requestDto.getId());
			if (userData == null) {
				return new CustomResponse(HttpStatus.OK.value(), "", "UserData does not exist");
			}
			if (userData.getEmail().equals(requestDto.getEmail())) {
				if (requestDto.getNewPassword() != null && !requestDto.getNewPassword().isEmpty()) {
					userData.setPassword(bcryptEncoder.encode(requestDto.getNewPassword()));
				}
			} else
				return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Invalid UserData");
			userData.setIsActive(requestDto.getIsActive());

			UserData userDataResponse = userDao.updateUser(userData);
			if (userDataResponse == null) {
				return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "Password Could not updated");
			}
			return new CustomResponse(HttpStatus.OK.value(), userData.getEmail(), "Password Successfully updated");
		} catch (Exception e) {
			LOGGER.error("Error in update UserData Password");
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, e.getMessage());
		}

	}

	@Override
	public CustomResponse forgetPassword(String email) {
		try {
			UserData existingUser = userRepository.findByEmailIgnoreCase(email);
			if (existingUser != null) {
				// Create token
				ConfirmationToken confirmationToken = new ConfirmationToken(existingUser);
				// Save it
				confirmationToken.setExpired(false);
				System.out.println(existingUser.getId());
				List<ConfirmationToken> confirmationTokenList = confirmationTokenRepository
						.getAllByUserId(existingUser.getId().longValue());
				for (ConfirmationToken obj : confirmationTokenList) {
					obj.setExpired(true);
					obj.setExpiredOn(new Date());
				}
				confirmationToken.setExpiredOn(DateUtil.dateAfterAddingDays(new Date(), 1));
				confirmationTokenList.add(confirmationToken);
				List<ConfirmationToken> confirmationTokenListResponse = confirmationTokenRepository
						.saveAll(confirmationTokenList);
				// Create the email
				if (confirmationToken != null) {
					String content = EmailConstant.getForgerPasswordContent(existingUser.getName(), confirmationToken);
					// Send the email
					String[] emailArray = { email };
					sendEmail(content, emailArray);
//                emailserviceImpl.checkMail1(content, emailArray);
					return new CustomResponse(HttpStatus.OK.value(), content, "Success", null);

				}

			}
			return new CustomResponse(HttpStatus.NOT_FOUND.value(), null,
					responseMessageConfig.getProperty("Master.GetNotFoundMessage") + email, null);
		} catch (Exception e) {
			LOGGER.error("Error in forget Password");
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, e.getMessage());
		}
	}

	@Override
	public CustomResponse resetPassword(JwtRequest jwtRequest) {
		try {
			ConfirmationToken token = confirmationTokenRepository
					.findByConfirmationToken(jwtRequest.getConfirmationToken());
			if (token != null) {
				if (token.getExpired() || token.getExpiredOn().before(new Date()))
					return new CustomResponse(HttpStatus.UNAUTHORIZED.value(), jwtRequest.getEmail(), "Link Expired..");
				UserData tokenUser = userDao.findByEmail(token.getUserId().getEmail());
				if (tokenUser.getEmail().equals(jwtRequest.getEmail())) {
					tokenUser.setPassword(bcryptEncoder.encode(jwtRequest.getPassword()));
					userRepository.save(tokenUser);
					return new CustomResponse(HttpStatus.OK.value(), jwtRequest.getEmail(),
							responseMessageConfig.getProperty("Master.GetSuccessMessage"));
				}
			}
			return new CustomResponse(HttpStatus.UNAUTHORIZED.value(), null, "Invalid Token");
		} catch (Exception e) {
			LOGGER.error("Error in reset Password");
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, e.getMessage());
		}

	}

	public void sendEmail(String content, String[] toEmailList) {
		try {
			SendEmailRequest newEmail = new SendEmailRequest();
			newEmail.setHost(host);
			newEmail.setPort(port);
			newEmail.setSenderEmail(username);
			newEmail.setToEmailIds(toEmailList);
			newEmail.setSubject(EmailConstant.Forget_Email_User_Subject);
			newEmail.setContent(content);
			newEmail.setSenderPassword(password);
			emailService.sendEmailV1(newEmail);

		} catch (Exception e) {
			LOGGER.error("Error in Send Email Method");

		}
	}

	@Override
	public CustomResponse getUser(IdNameDto idNameDto) {
		try {
			UserData user = userDao.getUserId(idNameDto.getId());
			if (user != null) {
				UserResponseDto userResponseDto = entitySetter.userToUserResponseDto(user);

				return new CustomResponse(HttpStatus.OK.value(), userResponseDto,
						responseMessagesPropertyConfig.getProperty("Master.GetSuccessMessage"), null);
			}
			return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
					responseMessagesPropertyConfig.getProperty(("Master.GetNotExistMessage")));
		} catch (Exception e) {
			LOGGER.error("Error in get All Users");
			return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, e.getMessage());
		}

	}

}
