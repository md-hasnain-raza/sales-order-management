package com.rst.sopm.jwt;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;

import com.fasterxml.jackson.annotation.JsonInclude;

public class JwtRequest implements Serializable {

	private static final long serialVersionUID = 5926468583005150707L;

	@NotEmpty(message = "The email address is required.")
	@Email(message = "The email address is invalid.", flags = { Flag.CASE_INSENSITIVE })
	private String email;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@Pattern(regexp = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9\\s]).{8,}", message = "invalid password entered ")
	private String password;

	private String confirmationToken;

	private String deviceId;

	public JwtRequest() {
	}

	public JwtRequest(String email, String password) {
		this.email = email;
		this.password = password;
	}

	public JwtRequest(String email, String password, String confirmationToken) {
		this.email = email;
		this.password = password;
		this.confirmationToken = confirmationToken;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmationToken() {
		return confirmationToken;
	}

	public void setConfirmationToken(String confirmationToken) {
		this.confirmationToken = confirmationToken;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
}