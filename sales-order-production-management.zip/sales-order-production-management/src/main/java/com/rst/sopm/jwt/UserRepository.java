package com.rst.sopm.jwt;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserData, Long> {
	@Query(value = "select * from user where id=?1", nativeQuery = true)
	UserData findByUserId(Long id);

	UserData findByEmailIgnoreCase(String email);

	@Query("SELECT new com.rst.sopm.jwt.IdNameDto (id,name) FROM UserData where isActive=1")
	List<IdNameDto> getAllDropDown();
	@Query("SELECT new com.rst.sopm.jwt.IdNameDto (id,name) FROM UserData where isActive=1 and id in ?1")
	List<IdNameDto> getAllUserNameByIds(Set<Long> userIds);

}
