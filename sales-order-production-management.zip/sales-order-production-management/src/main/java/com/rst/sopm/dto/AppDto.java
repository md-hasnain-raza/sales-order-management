package com.rst.sopm.dto;

import com.rst.sopm.jwt.TokenData;

public class AppDto {

    private Long id;
    private String name;
    private String endPointsApiUrl;
    private String appIconUrl;
    private Boolean isActive;
    private Long permissionCount;
    private Long roleCount;
    private Long groupCount;
    private TokenData tokenData;

    public AppDto() {}

    public AppDto(Long id, String name, String endPointsApiUrl, Boolean isActive) {
        this.id = id;
        this.name = name;
        this.endPointsApiUrl = endPointsApiUrl;
        this.isActive = isActive;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEndPointsApiUrl() {
        return endPointsApiUrl;
    }

    public void setEndPointsApiUrl(String endPointsApiUrl) {
        this.endPointsApiUrl = endPointsApiUrl;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public TokenData getTokenData() {
        return tokenData;
    }

    public void setTokenData(TokenData tokenData) {
        this.tokenData = tokenData;
    }

    public Long getPermissionCount() {
        return permissionCount;
    }

    public void setPermissionCount(Long permissionCount) {
        this.permissionCount = permissionCount;
    }

    public Long getRoleCount() {
        return roleCount;
    }

    public void setRoleCount(Long roleCount) {
        this.roleCount = roleCount;
    }

    public Long getGroupCount() {
        return groupCount;
    }

    public void setGroupCount(Long groupCount) {
        this.groupCount = groupCount;
    }

    public String getAppIconUrl() {
        return appIconUrl;
    }

    public void setAppIconUrl(String appIconUrl) {
        this.appIconUrl = appIconUrl;
    }
}
