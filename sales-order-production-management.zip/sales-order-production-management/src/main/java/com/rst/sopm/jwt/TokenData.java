package com.rst.sopm.jwt;

public class TokenData {
	private Long userId;
	private String userName;
	private String email;

	private Integer companyId;

	public TokenData() {
		super();
	}

	public TokenData(Long userId) {
		super();
		this.userId = userId;
	}

	public TokenData(Long userId, String userName, String email) {
		this.userId = userId;
		this.userName = userName;
		this.email = email;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	@Override
	public String toString() {
		return "TokenData{" + "userId=" + userId + ", userName='" + userName + '\'' + ", email='" + email + '\'' + '}';
	}
}
