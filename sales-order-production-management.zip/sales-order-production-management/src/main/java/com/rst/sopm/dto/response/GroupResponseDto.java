package com.rst.sopm.dto.response;

import java.util.List;

import com.rst.sopm.jwt.IdNameDto;

public class GroupResponseDto {
	private Long id;
	private String name;
	private IdNameDto parentGroup;
	private Long appId;

	private List<GroupResponseDto> groupResponseDtoList;
	private List<PermissionResponseDto> permissionResponseDtoList;

	public GroupResponseDto() {
	}

	public GroupResponseDto(Long id, String name, IdNameDto parentGroup, Long appId) {
		this.id = id;
		this.name = name;
		this.parentGroup = parentGroup;
		this.appId = appId;
	}

	public GroupResponseDto(Long id, String name, IdNameDto parentGroup, Long appId,
			List<GroupResponseDto> groupResponseDtoList, List<PermissionResponseDto> permissionResponseDtoList) {
		this.id = id;
		this.name = name;
		this.parentGroup = parentGroup;
		this.appId = appId;
		this.groupResponseDtoList = groupResponseDtoList;
		this.permissionResponseDtoList = permissionResponseDtoList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public IdNameDto getParentGroup() {
		return parentGroup;
	}

	public void setParentGroup(IdNameDto parentGroup) {
		this.parentGroup = parentGroup;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public List<GroupResponseDto> getGroupResponseDtoList() {
		return groupResponseDtoList;
	}

	public void setGroupResponseDtoList(List<GroupResponseDto> groupResponseDtoList) {
		this.groupResponseDtoList = groupResponseDtoList;
	}

	public List<PermissionResponseDto> getPermissionResponseDtoList() {
		return permissionResponseDtoList;
	}

	public void setPermissionResponseDtoList(List<PermissionResponseDto> permissionResponseDtoList) {
		this.permissionResponseDtoList = permissionResponseDtoList;
	}
}
