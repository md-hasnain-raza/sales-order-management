package com.rst.sopm.dto.response;

import java.util.List;

public class GroupHierarchyResponseDto {
	private List<GroupHierarchyResponseDto> childGroups;
	private List<PermissionResponseDto> permissions;
	private String groupName;
	private Long groupId;
	private Long groupCount;
	private Long permissionCount;

	public GroupHierarchyResponseDto() {
	}

	public GroupHierarchyResponseDto(List<GroupHierarchyResponseDto> childGroups,
			List<PermissionResponseDto> permissions, String groupName, Long groupId) {
		this.childGroups = childGroups;
		this.permissions = permissions;
		this.groupName = groupName;
		this.groupId = groupId;
	}

	public GroupHierarchyResponseDto(List<GroupHierarchyResponseDto> childGroups,
			List<PermissionResponseDto> permissions, String groupName, Long groupId, Long groupCount,
			Long permissionCount) {
		this.childGroups = childGroups;
		this.permissions = permissions;
		this.groupName = groupName;
		this.groupId = groupId;
		this.groupCount = groupCount;
		this.permissionCount = permissionCount;
	}

	public List<GroupHierarchyResponseDto> getChildGroups() {
		return childGroups;
	}

	public void setChildGroups(List<GroupHierarchyResponseDto> childGroups) {
		this.childGroups = childGroups;
	}

	public List<PermissionResponseDto> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<PermissionResponseDto> permissions) {
		this.permissions = permissions;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getGroupCount() {
		return groupCount;
	}

	public void setGroupCount(Long groupCount) {
		this.groupCount = groupCount;
	}

	public Long getPermissionCount() {
		return permissionCount;
	}

	public void setPermissionCount(Long permissionCount) {
		this.permissionCount = permissionCount;
	}
}
