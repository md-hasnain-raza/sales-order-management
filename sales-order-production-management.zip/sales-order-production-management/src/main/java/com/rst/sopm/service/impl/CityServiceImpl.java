package com.rst.sopm.service.impl;


import com.rst.sopm.dao.CityDao;
import com.rst.sopm.dto.CityDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.City;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;
import com.rst.sopm.service.CityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class CityServiceImpl implements CityService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private CityDao cityDao;

    @Override
    public CustomResponse saveCity(CityDto cityDto) {
        try {
            City city = new City();
            BeanUtils.copyProperties(cityDto, city);
            City savedCity = cityDao.save(city);
            if (savedCity != null) {
                return new CustomResponse(HttpStatus.OK.value(), cityDto, "City created successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), cityDto, "City already exists");
        } catch (Exception e) {
            LOGGER.error("Error occurred while creating city: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while creating city");
        }
    }

    @Override
    public CustomResponse updateCity(CityDto cityDto) {
        try {
            City city = new City();
            BeanUtils.copyProperties(cityDto, city);
            City updatedCity = cityDao.save(city);
            if (updatedCity != null) {
                return new CustomResponse(HttpStatus.OK.value(), cityDto, "City updated successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), cityDto, "City not found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating city: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while updating city");
        }
    }

    @Override
    public CustomResponse getAllCities(SearchDto searchDto) {
        try {
            List<City> cities = cityDao.getAll(searchDto);

            if (cities != null && !cities.isEmpty()) {
                List<CityDto> cityDtoList = new ArrayList<>();
                for (City city : cities) {
                    CityDto cityDto = new CityDto();
                    BeanUtils.copyProperties(city, cityDto);
                    cityDtoList.add(cityDto);
                }
                return new CustomResponse(HttpStatus.OK.value(), cityDtoList, "Cities retrieved successfully");
            }
            return new CustomResponse(HttpStatus.NOT_FOUND.value(), null, "No cities found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting cities: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while getting cities");
        }
    }

}
