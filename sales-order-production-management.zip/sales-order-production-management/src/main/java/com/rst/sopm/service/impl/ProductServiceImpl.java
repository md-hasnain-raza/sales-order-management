package com.rst.sopm.service.impl;


import com.rst.sopm.dao.ProductDao;
import com.rst.sopm.dto.IdCountDto;
import com.rst.sopm.dto.ProductDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.Product;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;
import com.rst.sopm.service.ProductService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Map;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ProductDao productDao;

    @Override
    public CustomResponse createProduct(ProductDto productDto) {
        try {
            Product product = new Product();
            BeanUtils.copyProperties(productDto, product);
            product.setIsActive(true);
            Product productDb = productDao.save(product);
            if (productDb != null) {
                return new CustomResponse(HttpStatus.OK.value(), productDto, "Product created successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), productDto, "Product already exists");
        } catch (Exception e) {
            LOGGER.error("Error occurred while creating product: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while creating product");
        }
    }

    @Override
    public CustomResponse getProduct(IdNameDto productId) {
        try {
            Product product = productDao.findById(productId.getId());
            if (product != null) {
                ProductDto productDto = new ProductDto();
                BeanUtils.copyProperties(product, productDto);
                return new CustomResponse(HttpStatus.OK.value(), productDto, "Product retrieved successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "No data found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting product: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while getting product");
        }
    }

    @Override
    public CustomResponse updateProduct(ProductDto productDto) {
        try {
            Product product = new Product();
            BeanUtils.copyProperties(productDto, product);
            Product productDb = productDao.save(product);
            if (productDb != null) {
                return new CustomResponse(HttpStatus.OK.value(), productDto, "Product updated successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), productDto, "Product already exists");
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating product: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while updating product");
        }
    }

    @Override
    public CustomResponse deactivateProduct(IdNameDto requestDto) {
        try {
            Product product = productDao.findById(requestDto.getId());
            if (product != null) {
                product.setIsActive(false);
                productDao.update(product);
                return new CustomResponse(HttpStatus.OK.value(), requestDto, "Product deactivated successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), requestDto, "Product not found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while deactivating product: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while deactivating product");
        }
    }

    @Override
    public CustomResponse getAllProducts(SearchDto requestDto) {
        try {
            List<Product> products = productDao.getAll(requestDto);

            if (products != null && !products.isEmpty()) {
                List<ProductDto> productDtoList = new ArrayList<>();
                for (Product product : products) {
                    ProductDto productDto = new ProductDto();
                    BeanUtils.copyProperties(product, productDto);
                    productDtoList.add(productDto);
                }
                return new CustomResponse(HttpStatus.OK.value(), productDtoList, "Products retrieved successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "No data found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting products: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while getting products");
        }
    }
}
