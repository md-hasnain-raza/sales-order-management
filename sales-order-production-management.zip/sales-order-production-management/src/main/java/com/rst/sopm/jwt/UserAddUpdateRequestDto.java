package com.rst.sopm.jwt;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;

public class UserAddUpdateRequestDto {
	private Long id;
	// @Pattern(regexp = "^\\d{10}$",message = "invalid mobile number entered ")
	// --mobile
	@NotNull
	@NotBlank
	private String userName;

	@NotNull
	private IdNameDto userType;

	private String userCode;

	private Long companyId;

	private Integer roleId;

	@NotEmpty(message = "The email address is required.")
	@Email(message = "The email address is invalid.", flags = { Flag.CASE_INSENSITIVE })
	private String email;
	@Pattern(regexp = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9\\s]).{8,}", message = "invalid password entered ")
	private String password;

	// @NotNull
	private String imageUrl;
	@NotNull
	private Boolean isActive;
	private Boolean isOnTrip;

	private Long siteId;

	@NotNull
	private TokenData tokenData;
	private Long consigneeId;

	public UserAddUpdateRequestDto() {
		super();
	}

	public UserAddUpdateRequestDto(Long id, String userName, IdNameDto userType, String userCode, Long companyId,
			Integer roleId, String email, String password, String imageUrl, Boolean isActive, Boolean isOnTrip,
			Long siteId, TokenData tokenData, Long consigneeId) {
		this.id = id;
		this.userName = userName;
		this.userType = userType;
		this.userCode = userCode;
		this.companyId = companyId;
		this.roleId = roleId;
		this.email = email;
		this.password = password;
		this.imageUrl = imageUrl;
		this.isActive = isActive;
		this.isOnTrip = isOnTrip;
		this.siteId = siteId;
		this.tokenData = tokenData;
		this.consigneeId = consigneeId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public IdNameDto getUserType() {
		return userType;
	}

	public void setUserType(IdNameDto userType) {
		this.userType = userType;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		isActive = active;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Long getConsigneeId() {
		return consigneeId;
	}

	public void setConsigneeId(Long consigneeId) {
		this.consigneeId = consigneeId;
	}

	public Boolean getIsOnTrip() {
		return isOnTrip;
	}

	public void setIsOnTrip(Boolean isOnTrip) {
		this.isOnTrip = isOnTrip;
	}
}