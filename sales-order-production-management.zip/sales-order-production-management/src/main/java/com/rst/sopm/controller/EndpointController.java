package com.rst.sopm.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
public class EndpointController {
	private final Map<RequestMappingInfo, String> requestMappings;

	public EndpointController(RequestMappingHandlerMapping requestMappingHandlerMapping) {
		this.requestMappings = requestMappingHandlerMapping.getHandlerMethods().entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getBeanType().getSimpleName()));
	}

	@GetMapping("/all/unmapped/endpoints")
	public List<String> getAllRequestUrisAndControllers() throws JsonProcessingException {
		Map<RequestMappingInfo, String> map = new HashMap<>(requestMappings);
		for (RequestMappingInfo obj : requestMappings.keySet()) {
			if (obj.getPatternsCondition().getPatterns().toString().startsWith("[/error]"))
				map.remove(obj);
		}

		Map<String, String> newMap = new HashMap<>();
		map.forEach((k, v) -> newMap.put(removeSquareBrackets(k.getPatternsCondition().getPatterns().toString()), v));

		Map<String, Set<String>> invertedMap = newMap.entrySet().stream().collect(
				Collectors.groupingBy(Map.Entry::getValue, Collectors.mapping(Map.Entry::getKey, Collectors.toSet())));

		List<String> endpoint = invertedMap.values().stream().flatMap(Collection::stream).collect(Collectors.toList());

		return endpoint;

	}

	private String removeSquareBrackets(String str) {
		if (str.startsWith("[") && str.endsWith("]")) {
			return str.substring(1, str.length() - 1);
		}
		return str;
	}

}
