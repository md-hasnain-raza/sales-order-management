package com.rst.sopm.controller;

import com.rst.sopm.dto.ClientDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.IdNameDto;
import com.rst.sopm.jwt.TokenData;
import com.rst.sopm.service.ClientService;
import com.rst.sopm.setter.RequestSetter;
import com.rst.sopm.util.CustomValidation;
import com.rst.sopm.util.LogUtil;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("api")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @Autowired
    private CustomValidation customValidation;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @ApiOperation("Client Add")
    @PostMapping("/add/client")
    public ResponseEntity<?> addClient(@RequestBody ClientDto clientDto, HttpServletRequest request){

        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            clientDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.saveClient(clientDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = clientService.saveClient(clientDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Update Client")
    @PostMapping("/update/client")
    public ResponseEntity<?> updateClient(@RequestBody ClientDto clientDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            clientDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.updateClient(clientDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = clientService.updateClient(clientDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Get All Client Data")
    @PostMapping("get/all/client")
    public ResponseEntity<?> getAllClient(@RequestBody ClientDto clientDto,HttpServletRequest request){
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            clientDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getAllClient(clientDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = clientService.getAllClient(clientDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);

    }

    @ApiOperation(value = "Get Client")
    @PostMapping("/get/client")
    public ResponseEntity<?> getClient(@RequestBody ClientDto clientDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            clientDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = customValidation.getClient(clientDto);

        if (response.getStatus().equals(HttpStatus.OK.value())) {
            response = clientService.getClient(clientDto);
        }

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

}
