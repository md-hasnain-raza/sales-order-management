package com.rst.sopm.jwt;

public class UserResponseDto {

	private Long id;
	private String name;
	private IdNameDto userType;
	private Boolean isActive;
	private String email;
	private IdNameDto company;

	public UserResponseDto(Long id, String name, IdNameDto userType, Boolean isActive, String email,
			IdNameDto company) {
		this.id = id;
		this.name = name;
		this.userType = userType;
		this.isActive = isActive;
		this.email = email;
		this.company = company;
	}

	public UserResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public IdNameDto getUserType() {
		return userType;
	}

	public void setUserType(IdNameDto userType) {
		this.userType = userType;
	}

	public Boolean getActive() {
		return isActive;
	}

	public void setActive(Boolean active) {
		isActive = active;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public IdNameDto getCompany() {
		return company;
	}

	public void setCompany(IdNameDto company) {
		this.company = company;
	}
}
