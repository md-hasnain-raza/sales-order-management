package com.rst.sopm.dao;

import java.util.List;

import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.CountryState;

public interface CountryStateDao {
	CountryState save(CountryState countrystate);

	CountryState update(CountryState countrystate);

	CountryState findById(Long id);

	List<CountryState> getAll(SearchDto search);
}
