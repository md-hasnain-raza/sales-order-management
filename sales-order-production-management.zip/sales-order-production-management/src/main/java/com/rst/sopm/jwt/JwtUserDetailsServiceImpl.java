package com.rst.sopm.jwt;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class JwtUserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private EntitySetter entitySetter;
	@Autowired
	private UserDao userDao;

	@Override
	public UserDetails loadUserByUsername(String search) throws UsernameNotFoundException {
		UserData user = userDao.findByUserCode(search);
		if (user == null) {
			throw new UsernameNotFoundException("UserData not found : " + search);
		}
		return new User(user.getName(), user.getPassword(), new ArrayList<>());
	}

	public UserResponseDto loadUserByLoginId(String search) throws UsernameNotFoundException {
		UserData user = userDao.findByUserCode(search);
		if (user == null)
			throw new UsernameNotFoundException("UserData not found : " + search);
		UserResponseDto userResponseDto = entitySetter.userToUserResponseDto(user);
		return userResponseDto;
	}

	public CustomUserDetails loadUserByEmail(String emailId) {

		if (emailId != null && emailId.contains(JwtTokenUtil.JWT_DELIMITER)) {
			String[] usernamePass = emailId.split(JwtTokenUtil.JWT_DELIMITER);
			emailId = usernamePass[0];
		}

		UserData user = userDao.findByEmail(emailId);
		if (user == null)
			throw new UsernameNotFoundException("UserData not found with username: " + emailId);
		return new CustomUserDetails(user.getEmail(), user.getPassword(), user.getId().longValue(), user.getName(),
				user.getCompany().getId().longValue(), user.getUserType());
	}

}
