package com.rst.sopm.jwt;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IdNameDto {
	private Long id;
	private Long permissionStateId;
	private List<Long> ids;
	private String name;
	private String key;
	private Boolean isActive;
	private Boolean isFinal;
	private TokenData tokenData;

	public IdNameDto(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	public IdNameDto(Long id, Long permissionStateId, String name, Boolean isFinal) {
		this.id = id;
		this.permissionStateId = permissionStateId;
		this.name = name;
		this.isFinal = isFinal;
	}

	public IdNameDto() {
	}

	public IdNameDto(Long id) {
		this.id = id;
		// TODO Auto-generated constructor stub
	}

	public Long getPermissionStateId() {
		return permissionStateId;
	}

	public void setPermissionStateId(Long permissionStateId) {
		this.permissionStateId = permissionStateId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		this.isActive = active;
	}

	public Boolean getIsFinal() {
		return isFinal;
	}

	public void setIsFinal(Boolean aFinal) {
		this.isFinal = aFinal;
	}

	public List<Long> getIds() {
		return ids;
	}

	public void setIds(List<Long> ids) {
		this.ids = ids;
	}

	@Override
	public String toString() {
		return "{" + "id:" + id + ", name:'" + name + '\'' + '}';
	}
}
