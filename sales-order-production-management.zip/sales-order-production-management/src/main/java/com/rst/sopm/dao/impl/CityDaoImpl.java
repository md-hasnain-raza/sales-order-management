package com.rst.sopm.dao.impl;


import com.rst.sopm.dao.CityDao;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.City;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CityDaoImpl implements CityDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public City save(City city) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a city with the same name already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<City> cr = cb.createQuery(City.class);
        Root<City> root = cr.from(City.class);

        List<Predicate> andPredicates = new ArrayList<>();
        andPredicates.add(cb.equal(cb.lower(root.get("name")), city.getName().trim().toLowerCase()));
        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<City> query = session.createQuery(cr);
        List<City> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another city with the same name already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with saving
        session.save(city);
        session.flush();
        session.clear();
        return city;
    }

    @Override
    public City update(City city) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a city with the same name already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<City> cr = cb.createQuery(City.class);
        Root<City> root = cr.from(City.class);

        List<Predicate> andPredicates = new ArrayList<>();
        andPredicates.add(cb.notEqual(root.get("id"), city.getId()));
        andPredicates.add(cb.equal(cb.lower(root.get("name")), city.getName().trim().toLowerCase()));
        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<City> query = session.createQuery(cr);
        List<City> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another city with the same name already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with updating
        session.merge(city);
        session.flush();
        session.clear();
        return city;
    }


    @Override
    public List<City> getAll(SearchDto search) {
        Session session = entityManager.unwrap(Session.class);
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<City> cr = cb.createQuery(City.class);
        Root<City> root = cr.from(City.class);

        List<Predicate> andPredicates = new ArrayList<>();

        // Add your search criteria here based on the SearchDto
        if (search.getSearchKey() != null) {
            Predicate namePredicate = cb.like(cb.lower(root.get("name")),
                    "%" + search.getSearchKey().toLowerCase() + "%");
            andPredicates.add(cb.or(namePredicate));
        }
        andPredicates.add(cb.equal(root.get("state").get("id"), search.getStateId()));

        // Build the query and return the results
        cr.select(root).where(cb.and(andPredicates.toArray(new Predicate[] {})));
        Query<City> query = session.createQuery(cr);

        // Apply pagination if required
        if (search.getPageSize() != null && search.getPageNumber() != null && search.getPageNumber() > 0
                && search.getPageSize() > 0) {
            query.setMaxResults(search.getPageSize());
            query.setFirstResult((search.getPageNumber() - 1) * search.getPageSize());
        }

        List<City> results = query.getResultList();

        session.flush();
        session.clear();

        return results;
    }
}
