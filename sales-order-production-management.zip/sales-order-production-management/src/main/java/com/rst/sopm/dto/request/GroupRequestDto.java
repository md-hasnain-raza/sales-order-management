package com.rst.sopm.dto.request;

import javax.validation.constraints.NotBlank;

import com.rst.sopm.jwt.TokenData;

public class GroupRequestDto {

	private Long id;
	private Long parentGroupId;
	private Long appId;
	@NotBlank(message = "Name is required")
	private String name;
	private TokenData tokenData;

	public GroupRequestDto() {
	}

	public GroupRequestDto(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentGroupId() {
		return parentGroupId;
	}

	public void setParentGroupId(Long parentGroupId) {
		this.parentGroupId = parentGroupId;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}