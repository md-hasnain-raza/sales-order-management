package com.rst.sopm.dto.request;

import com.rst.sopm.jwt.TokenData;

public class GetPermissionGroupHierarchyRequestDto {
	private Long groupId;
	private Long appId;

	private TokenData tokenData;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}
