package com.rst.sopm.dto.request;

import java.io.Serializable;
import java.util.Date;
import java.util.List; // Import List

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rst.sopm.jwt.TokenData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PermissionGroupMappingRequestDto implements Serializable {

	private Long id;
	private String name;
	private Long groupId;
	private Long appId;
	private Boolean isActive;
	private Date createdOn;
	private Long createdBy;
	private Date updatedOn;
	private Long updatedBy;
	private List<Long> permissionIds; // List of Permission IDs
	private Long permissionId; // List of Permission IDs
	private TokenData tokenData;

	// Getter and Setter methods for all fields

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<Long> getPermissionIds() {
		return permissionIds;
	}

	public void setPermissionIds(List<Long> permissionIds) {
		this.permissionIds = permissionIds;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}
