package com.rst.sopm.dto.request;

import com.rst.sopm.jwt.TokenData;

public class RoleRequestDto {

	private Long id;
	private String name;
	private String description;
	private Long companyId;
	private Long siteId;
	private Long appId;
	private Boolean isActive;
	private Long createdBy;
	private Long updatedBy;
	private TokenData tokenData;
	// Constructors, getters, and setters

	public RoleRequestDto() {
	}

	public RoleRequestDto(Long id, String name,String description, Long companyId, Long siteId, Long appId, Boolean isActive,
			Long createdBy, Long updatedBy, TokenData tokenData) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.companyId = companyId;
		this.siteId = siteId;
		this.appId = appId;
		this.isActive = isActive;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.tokenData = tokenData;
	}

	// Getters and setters for the properties

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;

	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}
