package com.rst.sopm.controller;


import com.rst.sopm.dto.CityDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.jwt.TokenData;
import com.rst.sopm.service.CityService;
import com.rst.sopm.setter.RequestSetter;
import com.rst.sopm.util.LogUtil;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api")
public class CityController {

    @Autowired
    private CityService cityService;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @ApiOperation("Add City")
    @PostMapping("/add/city")
    public ResponseEntity<?> addCity(@RequestBody CityDto cityDto, HttpServletRequest request){

        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            cityDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = cityService.saveCity(cityDto);

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation("Update City")
    @PostMapping("/update/city")
    public ResponseEntity<?> updateCity(@RequestBody CityDto cityDto, HttpServletRequest request) {
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        if (tokenData != null) {
            cityDto.setTokenData(tokenData);
        }
        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = cityService.updateCity(cityDto);

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

    @ApiOperation("Get All Cities")
    @PostMapping("/get/all/cities")
    public ResponseEntity<?> getAllCities(@RequestBody SearchDto searchDto, HttpServletRequest request){
        TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);

        LOGGER.info(LogUtil.beforeExecutionLogMessage(tokenData,
                Thread.currentThread().getStackTrace()[1].getMethodName()));

        CustomResponse response = cityService.getAllCities(searchDto);

        LOGGER.info(
                LogUtil.afterExecutionLogMessage(tokenData, Thread.currentThread().getStackTrace()[1].getMethodName()));

        return ResponseEntity.ok(response);
    }

}
