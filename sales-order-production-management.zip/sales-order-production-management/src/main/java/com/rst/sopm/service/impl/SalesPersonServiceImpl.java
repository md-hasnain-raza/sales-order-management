package com.rst.sopm.service.impl;

import com.rst.sopm.dao.SalesPersonDao;
import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.entity.SalesPerson;
import com.rst.sopm.jwt.*;
import com.rst.sopm.service.SalesPersonService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class SalesPersonServiceImpl implements SalesPersonService {

    @Autowired
    private SalesPersonDao salesPersonDao;

    @Autowired
    private UserServiceImpl userService;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public CustomResponse saveSalesPerson(SalesPersonDto salesPersonDto) {
        try {
            UserAddUpdateRequestDto userAddUpdateRequestDto = new UserAddUpdateRequestDto();
            userAddUpdateRequestDto.setUserName(salesPersonDto.getName());
            userAddUpdateRequestDto.setEmail(salesPersonDto.getEmail());
            userAddUpdateRequestDto.setIsActive(true);
            userAddUpdateRequestDto.setUserType(new IdNameDto(2L));
            userAddUpdateRequestDto.setCompanyId(1L);
            userAddUpdateRequestDto.setImageUrl("string");
            userAddUpdateRequestDto.setRoleId(1);
            userAddUpdateRequestDto.setUserCode(null);
            userAddUpdateRequestDto.setUserName("tiranga-lock-admin");
            userAddUpdateRequestDto.setPassword(salesPersonDto.getName()+"12321");
            CustomResponse customResponse =userService.save(userAddUpdateRequestDto);

            if(customResponse.getStatus().equals(HttpStatus.OK.value())){
                SalesPerson salesPerson =salesPersonDto.convertToEntity(salesPersonDto);
                UserData userData = (UserData) customResponse.getData();
                salesPerson.setUserData(userData);
                SalesPerson saveSalesPerson = salesPersonDao.save(salesPerson);
                return new CustomResponse(HttpStatus.OK.value(), saveSalesPerson,HttpStatus.OK.getReasonPhrase());
            }

            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,"Sales Person Not save!!");
        }catch (Exception e){
            LOGGER.error("Error Occured While Save the Sales Person" + e.getMessage(),e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred !!");
        }
    }

    @Override
    public CustomResponse updateSalesPerson(SalesPersonDto salesPersonDto) {
        try {
            SalesPerson salesPerson= salesPersonDto.convertToEntity(salesPersonDto);
            SalesPerson saveSalesPerson = salesPersonDao.save(salesPerson);
            if (salesPerson!=null) {
                return new CustomResponse(HttpStatus.OK.value(), saveSalesPerson, "Sales Person updated successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), saveSalesPerson, "Sales Person already exists");
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating Sales Person: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while updating Sales Person");
        }
    }

    @Override
    public CustomResponse getAllSalesPerson(SalesPersonDto salesPersonDto) {
        try {
            List<SalesPerson> salesPersonList = salesPersonDao.getAll(salesPersonDto);

            if (!salesPersonList.isEmpty()) {
                List<SalesPersonDto> salesPersonDtoList = new ArrayList<>();
                for (SalesPerson salesPerson : salesPersonList) {
                    SalesPersonDto returnSalesPersonDto =salesPerson.convertToDto(salesPerson);
                    salesPersonDtoList.add(returnSalesPersonDto);
                }
                Long totalElement = salesPersonDao.getAllTotalElements(salesPersonDto);
                return new CustomResponse(HttpStatus.OK.value(), salesPersonDtoList,
                        "Sales Person Details retrieved successfully",null,totalElement);
            } else {
                return new CustomResponse(HttpStatus.NOT_FOUND.value(), null, "No Sales Person Details found");
            }

        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching the data: " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while fetching the data");
        }
    }

    @Override
    public CustomResponse getSalesPerson(SalesPersonDto salesPersonDto) {
        try {
            SalesPerson salesPerson= salesPersonDao.findById(salesPersonDto.getId());
            if (salesPerson!=null) {
                SalesPersonDto returnSalesPersonDto=salesPerson.convertToDto(salesPerson);
                return new CustomResponse(HttpStatus.OK.value(), returnSalesPersonDto, "Sales Person retrieved successfully");
            }
            return new CustomResponse(HttpStatus.BAD_REQUEST.value(), null, "No data found");
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting Sales Person : " + e.getMessage(), e);
            return new CustomResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), null,
                    "Error occurred while getting Sales Person ");
        }
    }

}
