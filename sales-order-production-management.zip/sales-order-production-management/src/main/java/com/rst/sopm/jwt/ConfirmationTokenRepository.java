package com.rst.sopm.jwt;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfirmationTokenRepository extends JpaRepository<ConfirmationToken, Long> {
	@Query(value = "SELECT * FROM confirmation_token where confirmation_token=?1", nativeQuery = true)
	ConfirmationToken findByConfirmationToken(String confirmationToken);

	@Query(value = "SELECT * FROM confirmation_token where user_id=?1", nativeQuery = true)
	List<ConfirmationToken> getAllByUserId(Long id);
}
