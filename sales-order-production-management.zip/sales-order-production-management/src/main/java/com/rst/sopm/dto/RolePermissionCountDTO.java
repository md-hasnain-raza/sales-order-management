package com.rst.sopm.dto;

public class RolePermissionCountDTO {
	private Long roleId;
	private Long permissionCount;

	public RolePermissionCountDTO() {
	}

	public RolePermissionCountDTO(Long roleId, Long permissionCount) {
		this.roleId = roleId;
		this.permissionCount = permissionCount;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Long getPermissionCount() {
		return permissionCount;
	}

	public void setPermissionCount(Long permissionCount) {
		this.permissionCount = permissionCount;
	}
}
