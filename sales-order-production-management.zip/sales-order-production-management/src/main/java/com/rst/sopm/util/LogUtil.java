package com.rst.sopm.util;

import com.rst.sopm.jwt.TokenData;

public class LogUtil {

	public static final String beforeExecutionLogMessage(TokenData tokenData, String methodName) {

		return methodName + " execution initialized by user with code : "
				+ (tokenData != null ? tokenData.getEmail() : null) + " & name : "
				+ (tokenData != null ? tokenData.getUserName() : null) + " & companyId : "
				+ (tokenData != null ? tokenData.getCompanyId() : null);
	}

	public static final String afterExecutionLogMessage(TokenData tokenData, String methodName) {

		return methodName + " executed by user with code : " + (tokenData != null ? tokenData.getUserName() : null)
				+ " & name : " + (tokenData != null ? tokenData.getUserName() : null) + " & companyId : "
				+ (tokenData != null ? tokenData.getCompanyId() : null);
	}

}
