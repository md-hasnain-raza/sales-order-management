package com.rst.sopm.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sub_category_type_mapping")
public class SubCategoryTypeMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "parent_id")
	private Integer parentId;

	@Column(name = "category_id", nullable = false)
	private Integer categoryId;

	@Column(name = "sub_category_item_id", nullable = false)
	private Integer subCategoryItemId;

	@Column(name = "name", nullable = false, length = 45)
	private String name;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Column(name = "created_on", nullable = false)
	private Timestamp createdOn;

	@Column(name = "created_by", nullable = false)
	private Integer createdBy;

	@Column(name = "updated_on", nullable = false)
	private Timestamp updatedOn;

	@Column(name = "updated_by", nullable = false)
	private Integer updatedBy;

	public SubCategoryTypeMapping() {
	}

	public SubCategoryTypeMapping(Integer id, Integer parentId, Integer categoryId, Integer subCategoryItemId,
			String name, Boolean isActive, Timestamp createdOn, Integer createdBy, Timestamp updatedOn,
			Integer updatedBy) {
		this.id = id;
		this.parentId = parentId;
		this.categoryId = categoryId;
		this.subCategoryItemId = subCategoryItemId;
		this.name = name;
		this.isActive = isActive;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getSubCategoryItemId() {
		return subCategoryItemId;
	}

	public void setSubCategoryItemId(Integer subCategoryItemId) {
		this.subCategoryItemId = subCategoryItemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		this.isActive = active;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
}
