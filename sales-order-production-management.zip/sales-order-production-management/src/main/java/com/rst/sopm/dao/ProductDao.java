package com.rst.sopm.dao;



import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.Product;

import java.util.List;

public interface ProductDao {
    Product save(Product product);

    Product update(Product product);

    Product findById(Long id);

    List<Product> getAll(SearchDto search);
}
