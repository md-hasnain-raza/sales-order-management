package com.rst.sopm.dto;

import com.rst.sopm.entity.SalesPerson;
import com.rst.sopm.jwt.TokenData;
import com.rst.sopm.jwt.UserAddUpdateRequestDto;

import java.util.Date;

public class SalesPersonDto {

    private Long id;
    private String name;
    private String email;
    private String address;
    private String phoneNumber;
    private Boolean isActive;
    private Date createdOn;
    private Long createdBy;
    private Date updatedOn;
    private Long updatedBy;
    private TokenData tokenData;
    private UserAddUpdateRequestDto userAddUpdateRequestDto;
    private String searchKey;
    private Integer pageNumber;
    private Integer pageSize;

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Long getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Long updatedBy) {
        this.updatedBy = updatedBy;
    }

    public TokenData getTokenData() {
        return tokenData;
    }

    public void setTokenData(TokenData tokenData) {
        this.tokenData = tokenData;
    }

    public UserAddUpdateRequestDto getUserAddUpdateRequestDto() {
        return userAddUpdateRequestDto;
    }

    public void setUserAddUpdateRequestDto(UserAddUpdateRequestDto userAddUpdateRequestDto) {
        this.userAddUpdateRequestDto = userAddUpdateRequestDto;
    }

    public String getSearchKey() {
        return searchKey;
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public SalesPersonDto(Long id, String name, String email, String address, String phoneNumber, Boolean isActive, Date createdOn, Long createdBy, Date updatedOn, Long updatedBy) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.isActive = isActive;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.updatedOn = updatedOn;
        this.updatedBy = updatedBy;
    }

    public SalesPersonDto() {
    }

    public SalesPerson convertToEntity(SalesPersonDto salesPersonDto){
        SalesPerson salesPerson = new SalesPerson();
        salesPerson.setId(salesPersonDto.getId());
        salesPerson.setEmail(salesPersonDto.getEmail());
        salesPerson.setAddress(salesPersonDto.getAddress());
        salesPerson.setPhoneNumber(salesPersonDto.getPhoneNumber());
        salesPerson.setActive(true);
        salesPerson.setCreatedOn(new Date());
        salesPerson.setCreatedBy(1L);
        salesPerson.setUpdatedOn(new Date());
        salesPerson.setUpdatedBy(1L);
        return salesPerson;
    }
}
