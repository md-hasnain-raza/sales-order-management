package com.rst.sopm.dao.impl;

import com.rst.sopm.dao.SalesPersonDao;
import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.entity.SalesPerson;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class SalesPersonDaoImpl implements SalesPersonDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public SalesPerson save(SalesPerson salesPerson) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a Permission with the same name or apiEndpoint already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<SalesPerson> cr = cb.createQuery(SalesPerson.class);
        Root<SalesPerson> root = cr.from(SalesPerson.class);

        List<Predicate> andPredicates = new ArrayList<>();
        String salesPersonName = salesPerson.getName();
        if (salesPersonName != null) {
            andPredicates.add(cb.equal(cb.lower(root.get("name")), salesPersonName.trim().toLowerCase()));
        }

        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<SalesPerson> query = session.createQuery(cr);
        List<SalesPerson> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another Permission with the same name or apiEndpoint value already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with saving
        session.save(salesPerson);
        session.flush();
        session.clear();
        return salesPerson;
    }

    @Override
    public List<SalesPerson> getAll(SalesPersonDto salesPersonDto) {
        try {
            Session session = entityManager.unwrap(Session.class);
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<SalesPerson> cr = cb.createQuery(SalesPerson.class);
            Root<SalesPerson> root = cr.from(SalesPerson.class);

            List<Predicate> andPredicates = new ArrayList<>();

            // Add your search criteria here based on the SearchDto
            if (salesPersonDto.getSearchKey() != null) {
                // Filter by name and apiEndpoint using 'like' for partial matching
                Predicate namePredicate = cb.like(
                        cb.lower(root.get("name")),
                        "%" + salesPersonDto.getSearchKey().toLowerCase() + "%"
                );
                andPredicates.add(namePredicate);
            }

            // Add companyId filter
            if (salesPersonDto.getTokenData() != null && salesPersonDto.getTokenData().getCompanyId() != null) {
                Predicate companyIdPredicate = cb.equal(root.get("companyId"), salesPersonDto.getTokenData().getCompanyId());
                andPredicates.add(companyIdPredicate);
            }

            // Build the query and return the results
            cr.select(root).where(cb.and(andPredicates.toArray(new Predicate[0])));
            cr.orderBy(cb.desc(root.get("id")));
            Query<SalesPerson> query = session.createQuery(cr);

            // Apply pagination if required
            if (salesPersonDto.getPageSize() != null && salesPersonDto.getPageNumber() != null && salesPersonDto.getPageNumber() > 0
                    && salesPersonDto.getPageSize() > 0) {
                query.setMaxResults(salesPersonDto.getPageSize());
                query.setFirstResult((salesPersonDto.getPageNumber() - 1) * salesPersonDto.getPageSize());
            }

            List<SalesPerson> results = query.getResultList();

            session.flush();
            session.clear();

            return results;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Long getAllTotalElements(SalesPersonDto salesPersonDto) {
        Session session = entityManager.unwrap(Session.class);
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Long> cr = cb.createQuery(Long.class);
        Root<SalesPerson> root = cr.from(SalesPerson.class);

        List<Predicate> andPredicates = new ArrayList<>();

        if (salesPersonDto.getSearchKey() != null) {
            // Filter by name and apiEndpoint using 'like' for partial matching
            Predicate namePredicate = cb.like(
                    cb.lower(root.get("name")),
                    "%" + salesPersonDto.getSearchKey().toLowerCase() + "%"
            );
            andPredicates.add(namePredicate);
        }

        // Add companyId filter
        if (salesPersonDto.getTokenData() != null && salesPersonDto.getTokenData().getCompanyId() != null) {
            Predicate companyIdPredicate = cb.equal(root.get("companyId"), salesPersonDto.getTokenData().getCompanyId());
            andPredicates.add(companyIdPredicate);
        }
        // Build the query and return the count
        cr.select(cb.count(root)).where(cb.and(andPredicates.toArray(new Predicate[] {})));
        Query<Long> query = session.createQuery(cr);
        Long count = query.getSingleResult();

        session.flush();
        session.clear();

        return count;
    }

    @Override
    public SalesPerson findById(Long id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(SalesPerson.class, id);
    }
}
