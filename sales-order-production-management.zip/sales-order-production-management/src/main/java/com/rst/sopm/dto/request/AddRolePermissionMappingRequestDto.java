package com.rst.sopm.dto.request;

import java.util.Set;

import com.rst.sopm.jwt.TokenData;

public class AddRolePermissionMappingRequestDto {
	private Long roleId;
	private Set<Long> permissionIds;
	private Set<Long> groupIds;
	private Long appId;

	private Boolean isActive;
	private Long siteId;
	private Long companyId;
	private TokenData tokenData;

	public AddRolePermissionMappingRequestDto() {
	}

	public AddRolePermissionMappingRequestDto(Long roleId, Set<Long> permissionIds, Set<Long> groupIds, Long appId,
			Long siteId, Long companyId, TokenData tokenData, Boolean isActive) {
		this.roleId = roleId;
		this.permissionIds = permissionIds;
		this.groupIds = groupIds;
		this.appId = appId;
		this.siteId = siteId;
		this.companyId = companyId;
		this.tokenData = tokenData;
		this.isActive = isActive;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Set<Long> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(Set<Long> groupIds) {
		this.groupIds = groupIds;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Set<Long> getPermissionIds() {
		return permissionIds;
	}

	public void setPermissionIds(Set<Long> permissionIds) {
		this.permissionIds = permissionIds;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}
}
