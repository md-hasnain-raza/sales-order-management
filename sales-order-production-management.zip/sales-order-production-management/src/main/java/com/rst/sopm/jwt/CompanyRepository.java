package com.rst.sopm.jwt;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CompanyRepository extends JpaRepository<Company, Long> {

	@Query("SELECT new com.rst.sopm.jwt.IdNameDto (id,name) FROM Company where isActive=1")
	List<IdNameDto> getAllDropDown();
}