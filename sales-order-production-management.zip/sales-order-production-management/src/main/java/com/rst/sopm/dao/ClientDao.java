package com.rst.sopm.dao;

import com.rst.sopm.dto.ClientDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.Client;
import com.rst.sopm.jwt.UserData;

import java.util.List;

public interface ClientDao {


    Client save(Client client);

    Long getAllTotalElements(ClientDto clientDto);

    List<Client> getAll(ClientDto clientDto);

    Client findById(Long id);
}

