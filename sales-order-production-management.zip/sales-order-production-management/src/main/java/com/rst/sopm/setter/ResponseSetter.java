package com.rst.sopm.setter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.rst.sopm.dto.RolePermissionCountDTO;
import com.rst.sopm.dto.response.PermissionStateResponseDto;
import com.rst.sopm.dto.response.RoleResponseDto;
import com.rst.sopm.jwt.IdNameDto;

@Component
public class ResponseSetter {


}
