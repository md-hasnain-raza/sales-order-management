package com.rst.sopm.jwt;

public class CustomUserDetails {

	private String email;
	private String password;
	private Long userId;
	private String name;
	private Integer userType;
	private Long companyId;

	public CustomUserDetails() {
		super();
	}

	public CustomUserDetails(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}

	public CustomUserDetails(String email, String password, Long userId, String name, Long companyId,
			Integer userType) {
		this.email = email;
		this.password = password;
		this.userId = userId;
		this.name = name;
		this.companyId = companyId;
		this.userType = userType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}
}
