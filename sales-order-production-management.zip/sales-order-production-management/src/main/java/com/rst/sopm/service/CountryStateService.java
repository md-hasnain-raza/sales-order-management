package com.rst.sopm.service;

import com.rst.sopm.dto.CountryStateDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;

public interface CountryStateService {
	CustomResponse createCountryState(CountryStateDto countrystateDto);

	CustomResponse updateCountryState(CountryStateDto countrystateDto);

	CustomResponse getCountryState(Long id);

	CustomResponse getAllCountryStates(SearchDto searchDto);
}
