//package com.rst.sopm.config.redis.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.cache.Cache;
//import org.springframework.cache.CacheManager;
//import org.springframework.cache.annotation.CachePut;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.stereotype.Service;
//
//@Service
//public class PermissionCacheService {
//	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
//	private final CacheManager cacheManager;
//
//	public PermissionCacheService(CacheManager cacheManager) {
//		this.cacheManager = cacheManager;
//	}
//
//	@Cacheable(cacheNames = "permission", key = "#permissionId", unless = "#result == null")
//	public Permission getCachedPermissions(Long permissionId) {
//		try {
//			// This method is only used for caching, and its body won't be executed when
//			// permissions are found in the cache.
//			// Instead of returning null, we need to return the actual Permission objects
//			// from the cache.
//			// Since this method is used for caching and not fetching from the database, we
//			// can simply return an empty list here.
//			return null;
//		} catch (Exception e) {
//			// Log the exception
//			LOGGER.error("Error occurred while fetching cached permissions: " + e.getMessage(), e);
//			// Return an empty list or throw the exception as per your requirement
//			return null;
//		}
//	}
//
//	@CachePut(cacheNames = "permission", key = "#id")
//	public Permission saveCachedPermissions(Long id, Permission permissions) {
//		// This method is only used for caching, and its body won't be executed when
//		// caching is performed by Spring.
//		return permissions;
//	}
//
//	public List<Permission> getCachedPermissions(List<Long> permissionIds) {
//		List<Permission> cachedSubscriptions = new ArrayList<>();
//
//		Cache cache = cacheManager.getCache("permission");
//		if (cache != null) {
//			for (Long permissionId : permissionIds) {
//				Cache.ValueWrapper valueWrapper = cache.get(permissionId);
//				if (valueWrapper != null) {
//					Object cachedObject = valueWrapper.get();
//					if (cachedObject instanceof Permission) {
//						cachedSubscriptions.add((Permission) cachedObject);
//					}
//				}
//			}
//		}
//
//		return cachedSubscriptions;
//	}
//}
