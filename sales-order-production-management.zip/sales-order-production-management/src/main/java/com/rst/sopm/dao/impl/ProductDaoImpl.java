package com.rst.sopm.dao.impl;

import com.rst.sopm.dao.ProductDao;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.Product;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductDaoImpl implements ProductDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public Product save(Product product) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a product with the same name or SKU already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Product> cr = cb.createQuery(Product.class);
        Root<Product> root = cr.from(Product.class);

        List<Predicate> andPredicates = new ArrayList<>();
        andPredicates.add(cb.equal(cb.lower(root.get("name")), product.getName().trim().toLowerCase()));
        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<Product> query = session.createQuery(cr);
        List<Product> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another product with the same name or SKU already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with saving
        session.save(product);
        session.flush();
        session.clear();
        return product;
    }

    @Override
    public Product update(Product product) {
        Session session = entityManager.unwrap(Session.class);

        // Check if a product with the same name or SKU already exists
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Product> cr = cb.createQuery(Product.class);
        Root<Product> root = cr.from(Product.class);

        List<Predicate> andPredicates = new ArrayList<>();
        andPredicates.add(cb.notEqual(root.get("id"), product.getId()));
        andPredicates.add(cb.equal(cb.lower(root.get("name")), product.getName().trim().toLowerCase()));
        Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));

        cr.select(root).where(andPredicate);

        Query<Product> query = session.createQuery(cr);
        List<Product> results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            // Another product with the same name or SKU already exists
            session.flush();
            session.clear();
            return null;
        }

        // No conflicts, proceed with updating
        session.merge(product);
        session.flush();
        session.clear();
        return product;
    }

    @Override
    public Product findById(Long id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(Product.class, id);
    }

    @Override
    public List<Product> getAll(SearchDto search) {
        Session session = entityManager.unwrap(Session.class);
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Product> cr = cb.createQuery(Product.class);
        Root<Product> root = cr.from(Product.class);

        List<Predicate> andPredicates = new ArrayList<>();

        // Add your search criteria here based on the SearchDto
        if (search.getSearchKey() != null) {
            Predicate namePredicate = cb.like(cb.lower(root.get("name")),
                    "%" + search.getSearchKey().toLowerCase() + "%");
            andPredicates.add(cb.or(namePredicate));
        }

        // Build the query and return the results
        cr.select(root).where(cb.and(andPredicates.toArray(new Predicate[] {})));
        Query<Product> query = session.createQuery(cr);

        // Apply pagination if required
        if (search.getPageSize() != null && search.getPageNumber() != null && search.getPageNumber() > 0
                && search.getPageSize() > 0) {
            query.setMaxResults(search.getPageSize());
            query.setFirstResult((search.getPageNumber() - 1) * search.getPageSize());
        }

        List<Product> results = query.getResultList();

        session.flush();
        session.clear();

        return results;
    }
}
