package com.rst.sopm.jwt;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class UserPasswordUpdateRequestDto {
	private Long id;
	@NotEmpty(message = "The email address is required.")
	@Email(message = "The email address is invalid.", flags = { Pattern.Flag.CASE_INSENSITIVE })
	private String email;
	@Pattern(regexp = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9\\s]).{8,}", message = "invalid password entered ")
	private String newPassword;

	// private String password;
	@NotNull
	private TokenData tokenData;
	@NotNull
	private Boolean isActive;
	private String address;

	public UserPasswordUpdateRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserPasswordUpdateRequestDto(Long id, String email, String newPassword, TokenData tokenData,
			Boolean isActive) {
		this.id = id;
		this.email = email;
		// this.password = password;
		this.newPassword = newPassword;
		this.tokenData = tokenData;
		this.isActive = isActive;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
