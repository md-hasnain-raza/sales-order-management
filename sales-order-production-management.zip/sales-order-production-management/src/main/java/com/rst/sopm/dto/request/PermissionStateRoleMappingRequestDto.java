package com.rst.sopm.dto.request;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.rst.sopm.jwt.TokenData;

public class PermissionStateRoleMappingRequestDto {

	private Long id;
	@NotNull(message = "roleId is required")
	private Long roleId;

	@NotNull(message = "current state Id is required")
	private List<StatesRequestDto> statesRequestDtos;

	private Long permissionId;
	private Boolean isFinal;
	private TokenData tokenData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public List<StatesRequestDto> getStatesRequestDtos() {
		return statesRequestDtos;
	}

	public void setStatesRequestDtos(List<StatesRequestDto> statesRequestDtos) {
		this.statesRequestDtos = statesRequestDtos;
	}

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public TokenData getTokenData() {
		return tokenData;
	}

	public void setTokenData(TokenData tokenData) {
		this.tokenData = tokenData;
	}

	public Boolean getIsFinal() {
		return isFinal;
	}

	public void setIsFinal(Boolean isFinal) {
		this.isFinal = isFinal;
	}
}
