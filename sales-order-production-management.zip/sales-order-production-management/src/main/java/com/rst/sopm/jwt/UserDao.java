package com.rst.sopm.jwt;

import java.util.List;

public interface UserDao {

	UserData saveUser(UserData user);

	UserData updateUser(UserData user);

	UserData findByUserCode(String search);

	UserData findByEmail(String email);

	List<UserData> getAllExceptId(Long id);

	UserData getUserId(Long id);

	UserData getUserByEmail(String email);
}