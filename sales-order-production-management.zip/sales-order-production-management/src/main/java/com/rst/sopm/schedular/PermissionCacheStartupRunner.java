//package com.rst.sopm.schedular;
//
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.stereotype.Component;
//
//import com.rst.sopm.config.redis.service.PermissionCacheService;
//import com.rst.sopm.dto.SearchDto;
//import com.rst.sopm.jwt.CustomResponse;
//import com.rst.sopm.service.PermissionService;
//
//@Component
//public class PermissionCacheStartupRunner implements ApplicationRunner {
//
//	private final PermissionCacheService permissionCacheService;
//	private final PermissionService permissionService;
//
//	public PermissionCacheStartupRunner(PermissionCacheService permissionCacheService,
//			PermissionService permissionService) {
//		this.permissionCacheService = permissionCacheService;
//		this.permissionService = permissionService;
//	}
//
//	@Override
//	public void run(ApplicationArguments args) {
//		System.out.println("Running after application context initialization...");
//
//		// Load and cache permissions on application startup
//		loadAndCachePermissions();
//	}
//
//	private void loadAndCachePermissions() {
//		// Replace this with your logic to fetch permissions from your database using
//		// permissionService
//		CustomResponse response = permissionService.getAllPermissions(new SearchDto(0, 0));
//
//		if (response != null && response.getStatus() == 200) {
//
//			System.out.println("Permissions loaded and cached successfully.");
//		} else {
//			System.err.println("Failed to load and cache permissions.");
//		}
//	}
//}
