package com.rst.sopm.jwt;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("api/v1/user")
public class UserController {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	@Autowired
	EmailService emailService;

	@Autowired
	JwtValidation jwtValidation;
	@Autowired
	EntitySetter entitySetter;
	@Autowired
	private UserService userService;
//
//	@ApiOperation(value = "Forget Password")
//	@RequestMapping(value = "/forgot-password", method = RequestMethod.POST)
//	public ResponseEntity<?> forgotUserPassword(@RequestBody JwtRequest userAddUpdateRequestDto,
//			HttpServletRequest request)
//			throws NoSuchAlgorithmException, NoSuchProviderException, JsonProcessingException {
//
//		if (userAddUpdateRequestDto != null && userAddUpdateRequestDto.getEmail() != null
//				&& !userAddUpdateRequestDto.getEmail().isEmpty()) {
//			CustomResponse response = userService.forgetPassword(userAddUpdateRequestDto.getEmail());
//
//			return ResponseEntity.ok(response);
//		}
//
//		return new ResponseEntity<>(
//				new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//				HttpStatus.BAD_REQUEST);
//	}
//
//	@ApiOperation(value = "Reset Password")
//	@RequestMapping(value = "/reset-password", method = RequestMethod.POST)
//	public ResponseEntity<?> resetUserPassword(@RequestBody MasterRequestDto masterRequestDto)
//			throws UserNotFoundException, JsonProcessingException {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		JwtRequest jwtRequest = new JwtRequest();
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			jwtRequest = objectMapper.readValue(respData, JwtRequest.class);
//		}
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//			}
//
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			jwtRequest = objectMapper.readValue(decrBody, JwtRequest.class);
//		}
//		CustomResponse response = customValidation.validateResetPassword(jwtRequest);
//		if (response.getStatus().equals(HttpStatus.OK.value()))
//			response = userService.resetPassword(jwtRequest);
//
//		if (masterRequestDto.getEncKey() == 1) {
//			EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(response), token);
//
//			return ResponseEntity.ok(customResponseEnc);
//		}
//
//		return ResponseEntity.ok(response);
//	}
//
//	@ApiOperation(value = "update User Password")
//	@RequestMapping(value = "/update-user-password", method = RequestMethod.POST)
//	public ResponseEntity<?> updateUserPassword(@RequestBody MasterRequestDto masterRequestDto,
//			HttpServletRequest request) throws Exception {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		UserPasswordUpdateRequestDto requestDto = new UserPasswordUpdateRequestDto();
//
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			requestDto = objectMapper.readValue(respData, UserPasswordUpdateRequestDto.class);
//
//		}
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//			}
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			requestDto = objectMapper.readValue(decrBody, UserPasswordUpdateRequestDto.class);
//		}
//
//		if (requestDto == null) {
//			CustomResponse response = new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//					"UserRequest can't be null", null);
//			return new ResponseEntity<CustomResponse>(response, HttpStatus.BAD_REQUEST);
//		}
//		CustomResponse response = customValidation.validateUpdatePassword(requestDto);
//		if (response.getStatus() == HttpStatus.OK.value()) {
//			response = userService.updateUserPassword(requestDto);
//			if (masterRequestDto.getEncKey() == 1) {
//				EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(response), token);
//
//				return ResponseEntity.ok(customResponseEnc);
//			}
//
//			return ResponseEntity.ok(response);
//		}
//		return null;
//	}

	/*
	 * { "companyId": 1, "email": "mailto:tiranga@watsoo.com", "id": null,
	 * "imageUrl": "string", "isActive": true, "password": "Tiranga@2023#",
	 * "roleId": 1, "userType":1, "userCode": null, "userName": "tiranga-lock-admin"
	 * }
	 */

	@ApiOperation(value = "Add User")
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody UserAddUpdateRequestDto requestDto, HttpServletRequest request) {
		try {

			CustomResponse response = userService.save(requestDto);

			return ResponseEntity.ok(response);
		} catch (Exception e) {
			e.printStackTrace();

			return new ResponseEntity<CustomResponse>(new CustomResponse(), HttpStatus.BAD_REQUEST);
		}
	}

//	@ApiOperation(value = "Update User")
//	@RequestMapping(value = "/update", method = RequestMethod.POST)
//	public ResponseEntity<?> updateUser(@RequestBody @Valid MasterRequestDto masterRequestDto,
//			HttpServletRequest request) throws Exception {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		UserAddUpdateRequestDto requestDto = new UserAddUpdateRequestDto();
//
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			requestDto = objectMapper.readValue(respData, UserAddUpdateRequestDto.class);
//
//		}
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//
//			}
//
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			requestDto = objectMapper.readValue(decrBody, UserAddUpdateRequestDto.class);
//		}
//
//		TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);
//		if (tokenData != null) {
//			requestDto.setTokenData(tokenData);
//		}
//		CustomResponse response = customValidation.addUpdateUser(requestDto);
//
//		if (response.getStatus().equals(HttpStatus.OK.value())) {
//			response = apiAccessValidation.isAccessible(requestDto.getTokenData(), request.getRequestURI());
//			if (response.getStatus().equals(HttpStatus.OK.value()))
//				response = userService.update(requestDto);
//		}
//
//		LOGGER.info(LogUtil.afterExecutionLogMessage(requestDto.getTokenData(),
//				Thread.currentThread().getStackTrace()[1].getMethodName()));
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(response), token);
//
//			return ResponseEntity.ok(customResponseEnc);
//		}
//
//		return ResponseEntity.ok(response);
//	}
//
//	@ApiOperation(value = "Get All User")
//	@RequestMapping(value = "/fetchAll", method = RequestMethod.POST)
//	public ResponseEntity<?> getAllUsers(@RequestBody @Valid MasterRequestDto masterRequestDto,
//			HttpServletRequest request) throws JsonProcessingException {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		SearchDto searchDto = new SearchDto();
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			searchDto = objectMapper.readValue(respData, SearchDto.class);
//		}
//
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//
//			}
//
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			searchDto = objectMapper.readValue(decrBody, SearchDto.class);
//		}
//		TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);
//		if (tokenData != null) {
//			searchDto.setTokenData(tokenData);
//		}
//
//		CustomResponse response = userService.getAllUsers(searchDto);
//
//		if (response.getStatus() == HttpStatus.BAD_REQUEST.value()) {
//			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//		}
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(response), token);
//
//			return ResponseEntity.ok(customResponseEnc);
//		}
//
//		return ResponseEntity.ok(response);
//	}
//
//	@ApiOperation(value = "Get All User Drop down For trip")
//	@RequestMapping(value = "/getAllUsersByType", method = RequestMethod.POST)
//	public ResponseEntity<?> getAllUsersByType(@RequestBody @Valid MasterRequestDto masterRequestDto,
//			HttpServletRequest request) throws JsonProcessingException {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		IdNameDto idNameDto = new IdNameDto();
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			idNameDto = objectMapper.readValue(respData, IdNameDto.class);
//		}
//
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//
//			}
//
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			idNameDto = objectMapper.readValue(decrBody, IdNameDto.class);
//		}
//		TokenData tokenData = RequestSetter.getTokenDataFromHttpRequest(request);
//		if (tokenData != null) {
//			idNameDto.setTokenData(tokenData);
//		}
//
//		CustomResponse response = userService.getAllUsersByUserType(idNameDto);
//
//		if (response.getStatus() == HttpStatus.BAD_REQUEST.value()) {
//			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//		}
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(response), token);
//
//			return ResponseEntity.ok(customResponseEnc);
//		}
//
//		return ResponseEntity.ok(response);
//	}
//
//	@ApiOperation(value = "getUser by id")
//	@RequestMapping(value = "/getUser/By/Id", method = RequestMethod.POST)
//	public ResponseEntity<?> getUser(@RequestBody @Valid MasterRequestDto masterRequestDto, HttpServletRequest request)
//			throws JsonProcessingException {
//
//		String token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
//				.getHeader("Authorization").replace("Bearer ", "");
//
//		IdNameDto dto = new IdNameDto();
//		ObjectMapper objectMapper = new ObjectMapper();
//
//		if (masterRequestDto.getEncKey() != 1 || masterRequestDto.getEncKey() == 0
//				|| masterRequestDto.getEncKey() == null) {
//
//			if (masterRequestDto.getObject() == null) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Object.NoData")), HttpStatus.BAD_REQUEST);
//			}
//			String respData = objectMapper.writeValueAsString(masterRequestDto.getObject());
//			dto = objectMapper.readValue(respData, IdNameDto.class);
//		}
//		String timestamp = masterRequestDto.getTimeStamp();
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			if (masterRequestDto.getEncryptedRequestBody() == null
//					|| masterRequestDto.getEncryptedRequestBody().isEmpty()
//					|| masterRequestDto.getEncryptedRequestBody().equals("")) {
//				return new ResponseEntity<>(new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//						responseMessagesPropertyConfig.getProperty("Encrypt.NoData")), HttpStatus.BAD_REQUEST);
//			}
//
//			if (timestamp == null || timestamp.equals(null)) {
//
//				return new ResponseEntity<>(
//						new CustomResponse(HttpStatus.BAD_REQUEST.value(), null,
//								responseMessagesPropertyConfig.getProperty("Master.GetBadRequestMessage")),
//						HttpStatus.BAD_REQUEST);
//
//			}
//
//			String decrBody = AESUtil.decrypt(masterRequestDto.getEncryptedRequestBody(), timestamp, token);
//
//			dto = objectMapper.readValue(decrBody, IdNameDto.class);
//		}
//		CustomResponse customResponse = userService.getUser(dto);
//
//		if (customResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
//			return new ResponseEntity<>(customResponse, HttpStatus.BAD_REQUEST);
//		}
//
//		if (masterRequestDto.getEncKey() == 1) {
//
//			EncryptDto customResponseEnc = AESUtil.encrypt(new Gson().toJson(customResponse), token);
//
//			return ResponseEntity.ok(customResponseEnc);
//		}
//
//		return ResponseEntity.ok(customResponse);
//	}

}
