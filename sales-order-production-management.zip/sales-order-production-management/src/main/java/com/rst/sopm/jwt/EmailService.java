package com.rst.sopm.jwt;

import java.util.Map;

public interface EmailService {

//	public CustomResponse sendEmail(SendEmailRequest obj);

	CustomResponse sendEmailV1(SendEmailRequest obj);

	CustomResponse sendMail(MailRequest mail, Map<String, Object> model);
}
