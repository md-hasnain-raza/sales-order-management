package com.rst.sopm.dto.response;

import com.rst.sopm.jwt.IdNameDto;

public class PermissionResponseDto {

	private Long id;
	private String name;
	private String apiEndpoint;
	private Long appId;
	private Long rolePermissionMappingId;
	private Boolean isActive;
	private IdNameDto group;
	private Boolean isStateConfigured;
	private Boolean isStateMapped;

	public PermissionResponseDto() {
	}

	public PermissionResponseDto(Long id, String name, String apiEndpoint) {
		this.id = id;
		this.name = name;
		this.apiEndpoint = apiEndpoint;
	}

	public PermissionResponseDto(Long id, String name, String apiEndpoint, Long appId) {
		this.id = id;
		this.name = name;
		this.apiEndpoint = apiEndpoint;
		this.appId = appId;
	}

	public PermissionResponseDto(Long id, String name, String apiEndpoint, Long appId, Long rolePermissionMappingId,
			Boolean isActive) {
		this.id = id;
		this.name = name;
		this.apiEndpoint = apiEndpoint;
		this.appId = appId;
		this.rolePermissionMappingId = rolePermissionMappingId;
		this.isActive = isActive;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getApiEndpoint() {
		return apiEndpoint;
	}

	public void setApiEndpoint(String apiEndpoint) {
		this.apiEndpoint = apiEndpoint;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public IdNameDto getGroup() {
		return group;
	}

	public void setGroup(IdNameDto group) {
		this.group = group;
	}

	public Long getRolePermissionMappingId() {
		return rolePermissionMappingId;
	}

	public void setRolePermissionMappingId(Long rolePermissionMappingId) {
		this.rolePermissionMappingId = rolePermissionMappingId;
	}

	public Boolean getIsStateConfigured() {
		return isStateConfigured;
	}

	public void setIsStateConfigured(Boolean stateMapped) {
		this.isStateConfigured = stateMapped;
	}

	public Boolean getIsStateMapped() {
		return isStateMapped;
	}

	public void setIsStateMapped(Boolean stateMapped) {
		this.isStateMapped = stateMapped;
	}
}
