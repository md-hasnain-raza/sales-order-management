package com.rst.sopm.jwt;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private EntityManager entityManager;

	@Override
	public UserData saveUser(UserData user) {
		Session session = entityManager.unwrap(Session.class);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<UserData> cr = cb.createQuery(UserData.class);
		Root<UserData> root = cr.from(UserData.class);
		List<Predicate> orPredicates = new ArrayList<>();
		List<Predicate> andPredicates = new ArrayList<>();
		orPredicates.add(cb.equal(root.get("email"), user.getEmail().trim()));
//		andPredicates.add(cb.equal(root.get("userType"), user.getUserType()));
//        andPredicates.add(cb.equal(root.get("companyId"), user.getCompany().getId()));
		andPredicates.add(cb.equal(root.get("isActive"), true));
		Predicate orPredicate = cb.or(orPredicates.toArray(new Predicate[] {}));
		Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));
		cr.select(root).where(cb.and(andPredicate, orPredicate));
		Query<UserData> query = session.createQuery(cr);
		List<UserData> results = query.getResultList();
		if (results != null && results.size() > 0) {
			session.flush();
			session.clear();
			return null;
		}
		session.save(user);
		session.flush();
		session.clear();
		return user;

	}

	@Override
	public UserData updateUser(UserData user) {
		Session session = entityManager.unwrap(Session.class);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<UserData> cr = cb.createQuery(UserData.class);
		Root<UserData> root = cr.from(UserData.class);
		List<Predicate> andPredicates = new ArrayList<>();
		List<Predicate> orPredicates = new ArrayList<>();
		andPredicates.add(cb.notEqual(root.get("id"), user.getId()));
//        andPredicates.add(cb.equal(root.get("isActive"), user.getIsActive()));
		orPredicates.add(cb.equal(root.get("email"), user.getEmail()));
		Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));
		Predicate orPredicate = cb.or(orPredicates.toArray(new Predicate[] {}));
		cr.select(root).where(cb.and(andPredicate, orPredicate));
		// session.clear();
		Query<UserData> query = session.createQuery(cr);
		List<UserData> results = query.getResultList();
		if (results != null && results.size() > 0) {
			session.flush();
			session.clear();
			return null;

		}
		session.merge(user);
		session.flush();
		session.clear();
		return user;
	}

	@Override
	public UserData findByUserCode(String search) {
		Session session = entityManager.unwrap(Session.class);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<UserData> cr = cb.createQuery(UserData.class);
		Root<UserData> root = cr.from(UserData.class);
		List<Predicate> orPredicates = new ArrayList<>();
		List<Predicate> andPredicates = new ArrayList<>();
		if (search != null) {
//            orPredicates.add(cb.equal(cb.lower(root.get("userCode")), search.toLowerCase().trim()));
//			orPredicates.add(cb.equal(cb.lower(root.get("userName")), search.toLowerCase().trim()));
			orPredicates.add(cb.equal(cb.lower(root.get("email")), search.toLowerCase().trim()));
		}
		andPredicates.add(cb.equal(root.get("isActive"), true));
		Predicate orPredicate = cb.or(orPredicates.toArray(new Predicate[] {}));
		Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));
		cr.select(root).where(orPredicate, andPredicate);
		Query<UserData> query = session.createQuery(cr);
		List<UserData> results = query.getResultList();
		if (results.size() > 0) {
			session.flush();
			session.clear();
			return results.get(0);

		}
		session.flush();
		session.clear();
		return null;

	}

	@Override
	public UserData findByEmail(String email) {
		Session session = entityManager.unwrap(Session.class);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<UserData> cr = cb.createQuery(UserData.class);
		Root<UserData> root = cr.from(UserData.class);
		List<Predicate> andPredicates = new ArrayList<>();
		andPredicates.add(cb.equal(cb.lower(root.get("email")), email.toLowerCase().trim()));
		andPredicates.add(cb.equal(root.get("isActive"), true));
		Predicate andPredicate = cb.and(andPredicates.toArray(new Predicate[] {}));
		cr.select(root).where(andPredicate);
		Query<UserData> query = session.createQuery(cr);
		List<UserData> results = query.getResultList();
		if (results.size() > 0) {
			session.flush();
			session.clear();
			return results.get(0);

		}
		session.flush();
		session.clear();
		return null;

	}

	@Override
	public List<UserData> getAllExceptId(Long id) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserData> cq = cb.createQuery(UserData.class);
		Root<UserData> model = cq.from(UserData.class);
		cq.where(cb.notEqual(model.get("id"), id));
		TypedQuery<UserData> q = entityManager.createQuery(cq);
		return q.getResultList();
	}

	@Override
	public UserData getUserId(Long id) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserData> cq = cb.createQuery(UserData.class);
		Root<UserData> model = cq.from(UserData.class);
		cq.where(cb.equal(model.get("id"), id));
		TypedQuery<UserData> q = entityManager.createQuery(cq);
		return q.getSingleResult();
	}

	@Override
	public UserData getUserByEmail(String email) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserData> cq = cb.createQuery(UserData.class);
		Root<UserData> model = cq.from(UserData.class);
		cq.where(cb.equal(model.get("email"), email.toLowerCase().trim()));
		TypedQuery<UserData> q = entityManager.createQuery(cq);
		return q.getSingleResult();
	}
}