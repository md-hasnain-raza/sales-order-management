package com.rst.sopm.dao;



import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.entity.City;

import java.util.List;

public interface CityDao {

    City save(City city);

    City update(City city);

    List<City> getAll(SearchDto searchDto);
}
