package com.rst.sopm.entity;

import com.rst.sopm.dto.SalesPersonDto;
import com.rst.sopm.jwt.UserData;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "sales_person")
public class SalesPerson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "is_active",nullable = false)
    private Boolean isActive;

    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Column(name = "created_by", nullable = false)
    private Long createdBy;

    @Column(name = "updated_on")
    private Date updatedOn;

    @Column(name = "updated_by")
    private Long updatedBy;

    @OneToOne
    @JoinColumn(name = "user_id")
    private UserData userData;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Long getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Long updatedBy) {
        this.updatedBy = updatedBy;
    }

    public UserData getUserData() {
        return userData;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    public SalesPerson(String name, String email, String address, String phoneNumber, Boolean isActive, Date createdOn, Long createdBy, Date updatedOn, Long updatedBy) {
        this.name = name;
        this.email = email;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.isActive = isActive;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.updatedOn = updatedOn;
        this.updatedBy = updatedBy;
    }

    public SalesPerson() {
    }

    public SalesPersonDto convertToDto(SalesPerson salesPerson){
        SalesPersonDto salesPersonDto = new SalesPersonDto();
        salesPersonDto.setId(salesPerson.getId());
        salesPersonDto.setEmail(salesPerson.getEmail());
        salesPersonDto.setAddress(salesPerson.getAddress());
        salesPersonDto.setPhoneNumber(salesPerson.getPhoneNumber());
        salesPersonDto.setActive(true);
        salesPersonDto.setCreatedOn(new Date());
        salesPersonDto.setCreatedBy(1L);
        salesPersonDto.setUpdatedOn(new Date());
        salesPersonDto.setUpdatedBy(1L);
        return salesPersonDto;
    }
}
