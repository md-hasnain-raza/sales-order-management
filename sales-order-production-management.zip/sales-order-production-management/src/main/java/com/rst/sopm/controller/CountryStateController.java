package com.rst.sopm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rst.sopm.dto.CountryStateDto;
import com.rst.sopm.dto.SearchDto;
import com.rst.sopm.jwt.CustomResponse;
import com.rst.sopm.service.CountryStateService;

@RestController
@RequestMapping("/api/country-states")
public class CountryStateController {

	private final CountryStateService countryStateService;

	@Autowired
	public CountryStateController(CountryStateService countryStateService) {
		this.countryStateService = countryStateService;
	}


	@PostMapping("/create")
	public CustomResponse createCountryState(@RequestBody CountryStateDto countryStateDto) {
		return countryStateService.createCountryState(countryStateDto);
	}

	@PostMapping("/search")
	public CustomResponse getAllCountryStates(@RequestBody SearchDto searchDto) {
		return countryStateService.getAllCountryStates(searchDto);
	}
}
